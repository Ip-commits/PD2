Hooks:PostHook(PlayerMovement, "on_SPOOCed", "WhoAttackedMe:afterCloakerStrike", function()
	-- Original function has multiple return types, bool true means cloaker knocked down a player
	if WhoAttackedMe.settings.cloakerIncap_on and Hooks:GetReturn() == true then
		WhoAttackedMe:say(WhoAttackedMe.settings.cloakerIncap_msg)
	end
end)
