Hooks:PostHook(MenuItemInput, "setup_gui", "WhoAttackedMe:setupInputGui", function(self, node, row_item)
	if self.parameters and self:parameters().isCustomInput then
		if row_item.gui_panel then
			row_item.align = "left"
			row_item.gui_text:set_font_size(self:parameters().fSize or 18)
			row_item.empty_gui_text:set_font_size(self:parameters().fSize or 18)
			
			local rect = row_item.gui_panel:rect({
				blend_mode = "normal",
				name = "bg",
				halign = "grow",
				layer = node.layers.items - 1,
				valign = "grow",
				color = Color(0.35, 0, 0, 0)
			})
		end
	end
end)

Hooks:PreHook(MenuItemInput, "_layout", "WhoAttackedMe:preInputLayoutSet", function(self, row_item)
	if self.parameters and self:parameters().isCustomInput then
		self._align_right = row_item.gui_panel:w() - 5
		self._align_left = 5
	end
end)

Hooks:PreHook(MenuItemInput, "_set_enabled", "WhoAttackedMe:disableMouse", function(self, enabled)
	if self.parameters and self:parameters().isCustomInput then
		if not self:enabled() then
			return
		end
		
		if enabled then
			managers.mouse_pointer:suspendCallbacks()
		else
			managers.mouse_pointer:restoreCallbacks()
		end
	end
end)

local og = MenuItemInput.set_blinking
function MenuItemInput:set_blinking(b, row_item)
	if self.parameters and self:parameters().isCustomInput then
		local caret = row_item.caret
		caret:set_color(Color(0.9, 1, 1, 1))
	else
		og(self, b, row_item)
	end
end

Hooks:PostHook(MenuItemInput, "highlight_row_item", "WhoAttackedMe:hideInputBg", function(self, node, row_item)
	if self.parameters and self:parameters().isCustomInput then
		local bg = row_item.gui_panel:child("bg")
		if bg then
			bg:set_visible(false)
		end
	end
end)


Hooks:PostHook(MenuItemInput, "fade_row_item", "WhoAttackedMe:showInputBg", function(self, node, row_item)
	if self.parameters and self:parameters().isCustomInput then
		local bg = row_item.gui_panel:child("bg")
		if bg then
			bg:set_visible(true)
		end
	end
end)
