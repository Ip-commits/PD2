Hooks:PostHook(MenuItemDivider, "setup_gui", "WhoAttackedMe:setupDividerGui", function(self, node, row_item)
	if self.parameters then
		if self:parameters().isCustomTitle then
			for _, child in ipairs(row_item.gui_panel:children()) do
				if child.type_name == "Text" then
					child:set_font_size(self:parameters().fSize or 24)
					local x, y, w, h = child:text_rect()
					child:set_size(w, h)
					child:set_lefttop(0, 0)
					row_item.gui_panel:set_h(h)
				end
			end
		elseif self:parameters().showLine then
			local line = row_item.gui_panel:rect({
				name = "line",
				layer = node.layers.items + 2,
				h = 1.5,
				w = row_item.gui_panel:w(),
				color = Color(0.95, 0.95, 0.95),
				alpha = 0.15,
				blend_mode = "normal"
			})
			
			line:set_y(row_item.gui_panel:h() / 2)
		end
	end
end)
