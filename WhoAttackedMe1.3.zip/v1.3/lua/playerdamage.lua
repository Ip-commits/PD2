local msgPrinted = false
local lastUnit = nil

local function unitId(unit)
	local id = unit and unit.base and unit:base()._tweak_table
	if not id then return end
	if id == "tank" then
		local stats = unit:base()._stats_name
		if stats then
			return stats
		else
			return
		end
	elseif id == "shadow_spooc" then
		return "spooc"
	elseif id == "hector_boss_no_armor" then
		return "hector_boss"
	elseif id == "drug_lord_boss_stealth" then
		return "drug_lord_boss"
	elseif id == "triad_boss_no_armor" then
		return "triad_boss"
	end
	return id
end

Hooks:PostHook(PlayerDamage, "_calc_health_damage", "WhoAttackedMe:checkIfPlayerDowned", function(self, attack_data)				
	local unit = unitId(attack_data.attacker_unit)
	if unit then
		lastUnit = unit
	elseif not (attack_data.variant and attack_data.variant == "delayed_tick") then
		lastUnit = nil
	end
	if (not msgPrinted) and (self.swansong or self._bleed_out) and lastUnit then
		if WhoAttackedMe.settings[lastUnit .. "_on"] then
			WhoAttackedMe:say(WhoAttackedMe.settings[lastUnit .. "_msg"])
			msgPrinted = true
		end
	end
end)

Hooks:PostHook(PlayerDamage, "revive", "WhoAttackedMe:resetMsgStatus1", function()
	msgPrinted = false
	lastUnit = nil
end)

Hooks:PostHook(PlayerDamage, "on_arrested", "WhoAttackedMe:resetMsgStatus2", function()
	msgPrinted = false
	lastUnit = nil
end)

local taseLength = 0
Hooks:PostHook(PlayerDamage, "update", "WhoAttackedMe:taserZapCheck", function(self, unit, t)
	if WhoAttackedMe.settings.taserZap_on then
		if self._unit:movement():tased() and self._tase_data and
		self._tase_data.attacker_unit and self._tase_data.attacker_unit.base and
		self._tase_data.attacker_unit:base()._tweak_table == "taser" then
			if taseLength ~= -1 and t - taseLength > WhoAttackedMe.settings.taserZap_delay then
				taseLength = -1
				WhoAttackedMe:say(WhoAttackedMe.settings.taserZap_msg)
			end
		else
			taseLength = t
		end
	end
end)
