Hooks:PostHook(PlayerTased, "clbk_exit_to_fatal", "WhoAttackedMe:aferTaserFriesYou", function()
	if WhoAttackedMe.settings.taserIncap_on then
		WhoAttackedMe:say(WhoAttackedMe.settings.taserIncap_msg)
	end
end)
