Hooks:PostHook(GameSetup, "update", "Lasers:updateSetup", function(self, t, dt)
	Hooks:Call("UpdateLasersHook", t, dt)
end)