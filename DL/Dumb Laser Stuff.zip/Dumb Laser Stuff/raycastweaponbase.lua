local sync = true
local frequency = 0.15
local lastTime = -1
local currentTime = 0
Hooks:AddHook("UpdateLasersHook", "UpdateLaserState", function(t, dt)
	currentTime = t
	if lastTime == -1 then return end
	if currentTime - lastTime > frequency then
		local state = managers.player and managers.player:get_current_state()
		local weapon = state and state:get_equipped_weapon()
		if weapon and weapon:has_gadget() then
			weapon:gadget_off()
			if sync then
				local unit = managers.player:local_player()
				if unit and alive(unit) then
					unit:network():send("set_weapon_gadget_state", weapon._gadget_on)
				end
			end
			lastTime = -1
		end
	end
end)

Hooks:PostHook(RaycastWeaponBase, "fire", "Lasers:fire", function(self)
	if self._bullets_fired and self._bullets_fired > 0 and lastTime == -1 then
		local state = managers.player and managers.player:get_current_state()
		local weapon = state and state:get_equipped_weapon()
		if weapon and weapon:has_gadget() then
			weapon:gadget_on()
			if sync then
				local unit = managers.player:local_player()
				if unit and alive(unit) then
					unit:network():send("set_weapon_gadget_state", weapon._gadget_on)
					local gadget = weapon:get_active_gadget()
					if gadget and gadget.color then
						local col = gadget:color()
						unit:network():send("set_weapon_gadget_color", col.r * 255, col.g * 255, col.b * 255)
					end
				end
			end
			lastTime = currentTime
		end
	end
end)
