if not _G.BlockCharacters then
	_G.BlockCharacters = {}
	BlockCharacters.settings = {}
	BlockCharacters.savePath = SavePath .. 'Block_Characters.txt'
	
	function BlockCharacters:load()
		for _, v in pairs(CriminalsManager.character_names()) do
			self.settings[v] = false
		end
		
		local file = io.open(self.savePath, "r")
		if file then
			for k, v in pairs(json.decode(file:read("*all"))) do
				self.settings[k] = v
			end
			file:close()
			
			self:validateMinChars()
		else
			self:save()
		end
	end
	
	function BlockCharacters:validateMinChars(last)
		local chars = {
			"spanish",
			"german",
			"american",
			"russian"
		}
		
		if last then
			table.insert(chars, last)
		end
		
		local availableChars = 0
		for _, v in pairs(self.settings) do
			if not v then
				availableChars = availableChars + 1
			end
		end
		
		while #chars > 0 and availableChars < 4 do
			local char = table.remove(chars)
			if self.settings[char] then
				self.settings[char] = false
				availableChars = availableChars + 1
			end
		end
	end

	function BlockCharacters:save()
		local file = io.open(self.savePath, "w+")
		if file then
			file:write(json.encode(self.settings))
			file:close()
		end
	end
	
	function MenuCallbackHandler:cbBlockCharactersToggle(item)
		local name = item:parameters().name
		BlockCharacters.settings[name] = item:value() == "on"
		BlockCharacters:validateMinChars(name)
		if not BlockCharacters.settings[name] then
			item:set_value("off")
		end
	end
	
	function MenuCallbackHandler:cbBlockCharactersBack(item)
		BlockCharacters:save()
	end
	
	Hooks:Add("LocalizationManagerPostInit", "BlockCharacters:localizationInit", function(loc)
		loc:add_localized_strings({
			["locBlockCharacters1"] = "Block characters",
			["locBlockCharacters2"] = "Select characters to block",
			["locBlockCharacters3"] = "Block this character?"
		})
	end)
	
	Hooks:Add("MenuManagerSetupCustomMenus", "BlockCharacters:setupCustomMenus", function()
		MenuHelper:NewMenu("BlockCharactersMenu")
	end)
	
	Hooks:Add("MenuManagerPopulateCustomMenus", "BlockCharacters:populateCustomMenus", function()
		for k, v in pairs(BlockCharacters.settings) do
			MenuHelper:AddToggle({
				id = k,
				title = "menu_" .. k,
				desc = "locBlockCharacters3",
				callback = "cbBlockCharactersToggle",
				menu_id = "BlockCharactersMenu",
				value = BlockCharacters.settings[k]
			})
		end
	end)
	
	Hooks:Add("MenuManagerBuildCustomMenus", "BlockCharacters:buildCustomMenus", function(menu_manager, nodes)
		nodes["BlockCharactersMenu"] = MenuHelper:BuildMenu("BlockCharactersMenu", {back_callback = "cbBlockCharactersBack"})
		MenuHelper:AddMenuItem(nodes.blt_options, "BlockCharactersMenu", "locBlockCharacters1", "locBlockCharacters2")
	end)
	
	Hooks:Add("MenuManagerInitialize", "BlockCharacters:init", function()
		BlockCharacters:load()
	end)
end