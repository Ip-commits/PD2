function CriminalsManager:get_free_character_name()
	local preferred = managers.blackmarket:preferred_henchmen()

	for _, name in ipairs(preferred) do
		local data = table.find_value(self._characters, function (val)
			return val.name == name
		end)

		if data and not data.taken then
			print("chosen", name)

			return name
		end
	end

	local available = {}

	for id, data in pairs(self._characters) do
		local taken = data.taken
		local level_blocked = self:is_character_as_AI_level_blocked(data.name)
		local character_name = CriminalsManager.convert_old_to_new_character_workname(data.name)
		local character_table = tweak_data.blackmarket.characters[character_name] or tweak_data.blackmarket.characters.locked[character_name]
		local dlc_unlocked = not character_table or not character_table.dlc or managers.dlc:is_dlc_unlocked(character_table.dlc)

		if not taken and not level_blocked and dlc_unlocked then
			table.insert(available, data.name)
		end
	end

	if #available > 0 then
		return available[math.random(#available)]
	end
end

Hooks:PostHook(CriminalsManager, "get_free_character_name", "BlockCharacters:getFreeCharName", function(self)
	local freeChars = {}
	for k, v in pairs(BlockCharacters.settings) do
		if not v then
			table.insert(freeChars, k)
		end
	end
	
	-- fail-safe
	local backup = {
		"spanish",
		"german",
		"american",
		"russian"
	}
	
	while #freeChars < 4 do
		local char = table.remove(backup)
		if not table.contains(freeChars, char) then
			table.insert(freeChars, char)
		end
	end
	
	local preferredChars = managers.blackmarket:preferred_henchmen()
	for _, preferred in ipairs(preferredChars) do
		local data = table.find_value(self._characters, function (val)
			return val.name == preferred
		end)
		
		if data and not data.taken and table.contains(freeChars, preferred) then
			return preferred
		end
	end
	
	return freeChars[math.random(#freeChars)]
end)
