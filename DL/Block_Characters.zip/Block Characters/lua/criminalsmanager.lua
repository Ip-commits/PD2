Hooks:PostHook(CriminalsManager, "get_free_character_name", "BlockCharacters:getFreeCharName", function(self)
	if BlockCharacters and BlockCharacters.settings then
		local freeChars = {}
		for k, v in pairs(BlockCharacters.settings) do
			if not v then
				table.insert(freeChars, k)
			end
		end
		
		-- fail-safe
		local backup = {
			"spanish",
			"german",
			"american",
			"russian"
		}
		
		while #freeChars < 4 and #backup > 0 do
			local name = table.remove(backup)
			if not table.contains(freeChars, name) then
				table.insert(freeChars, name)
			end
		end
		
		for _, name in ipairs(freeChars) do
			local data = table.find_value(self._characters, function(val)
				return val.name == name
			end)
			
			if data and data.taken then
				table.delete(freeChars, name)
			end
		end
		
		if #freeChars > 0 then
			local preferredChars = managers.blackmarket:preferred_henchmen()
			for _, name in ipairs(preferredChars) do
				if table.contains(freeChars, name) then
					return name
				end
			end
			
			return freeChars[math.random(#freeChars)]
		end
	end
end)
