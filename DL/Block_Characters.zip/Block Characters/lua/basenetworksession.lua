Hooks:PostHook(BaseNetworkSession, "check_peer_preferred_character", "BlockCharacters:peerPrefChar", function(self, preferred_character)
	local freeChars = {}
	for k, v in pairs(BlockCharacters.settings) do
		if not v then
			table.insert(freeChars, k)
		end
	end

	for _, peer in pairs(self._peers_all) do
		table.delete(freeChars, peer:character())
	end
	
	-- fail-safe if there are no other chars
	if #freeChars < 4 then
		local chars = {
			"spanish",
			"german",
			"american",
			"russian"
		}
		
		for _, peer in pairs(self._peers_all) do
			local char = peer:character()
			if table.contains(chars, char) then
				table.delete(chars, char)
			end
		end
		
		freeChars = clone(chars)
	end
	
	local preferredChars = string.split(preferred_character, " ")
	for _, preferred in ipairs(preferredChars) do
		if table.contains(freeChars, preferred) then
			return preferred
		end
	end
	
	return freeChars[math.random(#freeChars)]
end)