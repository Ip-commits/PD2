local updateEvery = 5 -- seconds
local total = 0

Hooks:Add("MenuManagerInitialize", "OverridePersists", function()
	Hooks:RemovePostHook("BLTPersistScripts.MenuUpdate")
	Hooks:Add("MenuUpdate", "BLTPersistScripts.MenuUpdate", function(t, dt)
		total = total + dt
		if total >= updateEvery then
			BLTPersistScripts:update_persists()
			total = 0
		end
	end)
	
	Hooks:RemovePostHook("BLTPersistScripts.GameSetupUpdate")
	Hooks:Add( "GameSetupUpdate", "BLTPersistScripts.GameSetupUpdate", function(t, dt)
		total = total + dt
		if total >= updateEvery then
			BLTPersistScripts:update_persists()
			total = 0
		end
	end)
end)