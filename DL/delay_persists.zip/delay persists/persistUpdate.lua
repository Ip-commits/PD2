local updateEvery = 5 -- seconds
local totalA = 0
local totalB = 0

Hooks:Add("MenuManagerInitialize", "OverridePersists", function()
	Hooks:RemovePostHook("BLTPersistScripts.MenuUpdate")
	Hooks:Add("MenuUpdate", "BLTPersistScripts.MenuUpdate", function(t, dt)
		totalA = totalA + dt
		if totalA >= updateEvery then
			BLTPersistScripts:update_persists()
			totalA = 0
		end
	end)
	
	Hooks:RemovePostHook("BLTPersistScripts.GameSetupUpdate")
	Hooks:Add( "GameSetupUpdate", "BLTPersistScripts.GameSetupUpdate", function(t, dt)
		totalB = totalB + dt
		if totalB >= updateEvery then
			BLTPersistScripts:update_persists()
			totalB = 0
		end
	end)
end)