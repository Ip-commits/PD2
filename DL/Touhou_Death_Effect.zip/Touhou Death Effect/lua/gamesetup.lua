if not _G.TouhouDeathSFX then
	_G.TouhouDeathSFX = {}
	local audioFile = ModPath .. "assets/audio/sfx_player_dead.ogg"
	
	if blt.xaudio and io.file_is_readable(audioFile) then
		blt.xaudio.setup()
		TouhouDeathSFX.sound = XAudio.Buffer:new(audioFile)
	end
	
	function TouhouDeathSFX:playSound(pos)
		if not self.sound or not pos then
			return
		end
		
		local src = XAudio.Source:new(self.sound)
		if src then
			src:set_position(pos)
			src:set_volume(0.65)
		end
	end
end