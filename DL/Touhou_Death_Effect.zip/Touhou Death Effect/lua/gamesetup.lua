if not _G.TouhouDeathSFX then
	_G.TouhouDeathSFX = {}
	local audioFile = ModPath .. "assets/audio/sfx_player_dead.ogg"
	
	if blt.xaudio and io.file_is_readable(audioFile) then
		blt.xaudio.setup()
		TouhouDeathSFX.sound = XAudio.Buffer:new(audioFile)
	end
	
	function TouhouDeathSFX:playEffect(pos)
		if not pos then	return end
		World:effect_manager():spawn({
			effect = Idstring("effects/custom/th_points_effect"),
			position = pos + math.UP * 120,
			normal = math.UP
		})
		
		if not self.sound then return end
		local src = XAudio.Source:new(self.sound)
		if src then
			src:set_position(pos)
			src:set_volume(0.45)
		end
	end
end