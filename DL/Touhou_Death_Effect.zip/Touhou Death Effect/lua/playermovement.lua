Hooks:PostHook(PlayerMovement, "change_state", "PlayerMovement:spawnTHItems", function(self, name)
	if not game_state_machine:verify_game_state(GameStateFilters.any_ingame_playing) or not self._unit or not self._unit.position then
		return
	end
	
	if TouhouDeathSFX and (name == "bleed_out" or name == "incapacitated") then
		TouhouDeathSFX:playEffect(self._unit:position())
	end
end)
