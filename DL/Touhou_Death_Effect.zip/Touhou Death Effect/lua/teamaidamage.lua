Hooks:PostHook(TeamAIDamage, "_check_bleed_out", "TeamAIDamage:spawnTHItemsBleedout", function(self)
	if not game_state_machine:verify_game_state(GameStateFilters.any_ingame_playing) or not self._unit or not self._unit.position or not self._bleed_out then
		return
	end
	
	if TouhouDeathSFX then
		TouhouDeathSFX:playEffect(self._unit:position())
	end
end)

Hooks:PostHook(TeamAIDamage, "_on_incapacitated", "TeamAIDamage:spawnTHItemsIncapacitated", function(self)
	if not game_state_machine:verify_game_state(GameStateFilters.any_ingame_playing) or not self._unit or not self._unit.position then
		return
	end
	
	if TouhouDeathSFX then
		TouhouDeathSFX:playEffect(self._unit:position())
	end
end)