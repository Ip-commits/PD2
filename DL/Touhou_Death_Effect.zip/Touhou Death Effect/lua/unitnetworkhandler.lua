Hooks:PostHook(UnitNetworkHandler, "sync_player_movement_state", "UnitNetworkHandler:syncPeerTHItems", function(self, unit, state, down_time, unit_id_str, sender)
	if not game_state_machine:verify_game_state(GameStateFilters.any_ingame_playing) or not unit or not unit.position then
		return
	end
	
	if TouhouDeathSFX and (state == "bleed_out" or state == "incapacitated") then
		TouhouDeathSFX:playEffect(unit:position())
	end
end)
