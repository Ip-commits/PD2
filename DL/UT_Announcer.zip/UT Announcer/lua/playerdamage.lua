Hooks:PostHook(PlayerDamage, "revive", "UTAnnouncer:playerRevive", function()
	managers.player:UTAnnouncerResetStreak()
end)

Hooks:PostHook(PlayerDamage, "on_arrested", "UTAnnouncer:playerArrest", function()
	managers.player:UTAnnouncerResetStreak()
end)