if not _G.UTAnnouncer then
	_G.UTAnnouncer = {}
	UTAnnouncer.savePath = SavePath .. "UTAnnouncer.txt"
	UTAnnouncer.settings = {}
	
	function UTAnnouncer:defaultSettings()
		self.settings = {
			soundEnabled = true,
			textsEnabled = true,
			textTopYPos = 0.15,
			textTopXPos = 0.5,
			textBottomYPos = 0.85,
			textBottomXPos = 0.5,
			textScale = 1.15,
			volume = 1
		}
	end
	
	function UTAnnouncer:load()
		local file = io.open(self.savePath, "r")
		if file then
			for k, v in pairs(json.decode(file:read("*all"))) do
				self.settings[k] = v
			end
			file:close()
		else
			self:save()
		end
	end

	function UTAnnouncer:save()
		local file = io.open(self.savePath, "w+")
		if file then
			file:write(json.encode(self.settings))
			file:close()
		end
	end
	
	Hooks:Add("MenuManagerInitialize", "UTAnnouncer:menuManagerInit", function()
		UTAnnouncer:defaultSettings()
		UTAnnouncer:load()
	end)
	
	Hooks:Add("MenuManagerSetupCustomMenus", "UTAnnouncer:setupCustomMenus", function()
		MenuHelper:NewMenu("UTAnnouncerMenu")
	end)
	
	Hooks:Add("LocalizationManagerPostInit", "UTAnnouncer:localizationInit", function(loc)
		loc:add_localized_strings({
			["locUTAnnouncerMenu"] = "UT Announcer",
			["locUTAnnouncerMenuDesc"] = "Options for UT announcer",
		})
	end)
	
	Hooks:Add("MenuManagerPopulateCustomMenus", "UTAnnouncer:populateCustomMenus", function()
		MenuHelper:AddToggle({
			id = "soundEnabled",
			title = "Play sound",
			desc = "Toggle sound",
			callback = "cbUTAnnouncerToggle",
			value = UTAnnouncer.settings.soundEnabled,
			menu_id = "UTAnnouncerMenu",
			localized = false,
			priority = 9
		})
		
		MenuHelper:AddToggle({
			id = "textsEnabled",
			title = "Show text",
			desc = "Toggle text being displayed",
			callback = "cbUTAnnouncerToggle",
			value = UTAnnouncer.settings.textsEnabled,
			menu_id = "UTAnnouncerMenu",
			localized = false,
			priority = 8
		})
		
		MenuHelper:AddSlider({
			id = "textTopYPos",
			title = "Upper text Y position",
			desc = "How much the upper text is offset from the top of the hud's rectangle",
			callback = "cbUTAnnouncerSlider",
			value = UTAnnouncer.settings.textTopYPos,
			min = 0,
			max = 1,
			step = 0.05,
			show_value = true,
			menu_id = "UTAnnouncerMenu",
			localized = false,
			display_precision = 0,
			is_percentage = true,
			display_scale = 100,
			priority = 6
		})
		
		MenuHelper:AddSlider({
			id = "textTopXPos",
			title = "Upper text X position",
			desc = "How much the upper text is offset from the left of the hud's rectangle",
			callback = "cbUTAnnouncerSlider",
			value = UTAnnouncer.settings.textTopXPos,
			min = 0,
			max = 1,
			step = 0.05,
			show_value = true,
			menu_id = "UTAnnouncerMenu",
			localized = false,
			display_precision = 0,
			is_percentage = true,
			display_scale = 100,
			priority = 7
		})
		
		MenuHelper:AddSlider({
			id = "textBottomYPos",
			title = "Lower text Y position",
			desc = "How much the lower text is offset from the top of the hud's rectangle",
			callback = "cbUTAnnouncerSlider",
			value = UTAnnouncer.settings.textBottomYPos,
			min = 0,
			max = 1,
			step = 0.05,
			show_value = true,
			menu_id = "UTAnnouncerMenu",
			localized = false,
			display_precision = 0,
			is_percentage = true,
			display_scale = 100,
			priority = 4
		})
		
		MenuHelper:AddSlider({
			id = "textBottomXPos",
			title = "Lower text X position",
			desc = "How much the lower text is offset from the left of the hud's rectangle",
			callback = "cbUTAnnouncerSlider",
			value = UTAnnouncer.settings.textBottomXPos,
			min = 0,
			max = 1,
			step = 0.05,
			show_value = true,
			menu_id = "UTAnnouncerMenu",
			localized = false,
			display_precision = 0,
			is_percentage = true,
			display_scale = 100,
			priority = 5
		})
		
		MenuHelper:AddSlider({
			id = "textScale",
			title = "Text scale",
			desc = "Scale of announcement texts",
			callback = "cbUTAnnouncerSlider",
			value = UTAnnouncer.settings.textScale,
			min = 0.25,
			max = 2.5,
			step = 0.05,
			show_value = true,
			menu_id = "UTAnnouncerMenu",
			localized = false,
			display_precision = 0,
			is_percentage = true,
			display_scale = 100,
			priority = 3
		})
		
		MenuHelper:AddSlider({
			id = "volume",
			title = "Volume",
			desc = "Volume of announcements",
			callback = "cbUTAnnouncerSlider",
			value = UTAnnouncer.settings.volume,
			min = 0,
			max = 1,
			step = 0.05,
			show_value = true,
			menu_id = "UTAnnouncerMenu",
			localized = false,
			display_precision = 0,
			is_percentage = true,
			display_scale = 100,
			priority = 2
		})
		
		MenuHelper:AddButton({
			id = "defaults",
			title = "Reset to defaults",
			desc = "Reset settings to initial values",
			callback = "cbUTAnnouncerBtn",
			menu_id = "UTAnnouncerMenu",
			localized = false,
			priority = 1,
		})
	end)

	Hooks:Add("MenuManagerBuildCustomMenus", "UTAnnouncer:buildCustomMenus", function(menu_manager, nodes)
		nodes["UTAnnouncerMenu"] = MenuHelper:BuildMenu("UTAnnouncerMenu", {back_callback = "cbUTAnnouncerBack"})
		MenuHelper:AddMenuItem(nodes.blt_options, "UTAnnouncerMenu", "locUTAnnouncerMenu", "locUTAnnouncerMenuDesc")
	end)
	
	function MenuCallbackHandler:cbUTAnnouncerBtn(item)
		UTAnnouncer:defaultSettings()
		local menu = MenuHelper:GetMenu("UTAnnouncerMenu")
		for _, itm in ipairs(menu:items()) do
			local name = itm:parameters().name
			if UTAnnouncer.settings[name] ~= nil then
				if itm:parameters().type == "CoreMenuItemToggle.ItemToggle" then
					itm:set_value(UTAnnouncer.settings[name] and "on" or "off")
				else
					itm:set_value(UTAnnouncer.settings[name])
				end
			end
		end
		UTAnnouncer:save()
	end
	
	function MenuCallbackHandler:cbUTAnnouncerBack(item)
		UTAnnouncer:save()
	end

	function MenuCallbackHandler:cbUTAnnouncerSlider(item)
		UTAnnouncer.settings[item:name()] = tonumber(item:value())
		UTAnnouncer:save()
	end


	function MenuCallbackHandler:cbUTAnnouncerToggle(item)
		UTAnnouncer.settings[item:name()] = item:value() == "on"
		UTAnnouncer:save()
	end
end