if UTAnnouncer then
	function UTAnnouncer:setup()
		self.buffers = {}
		self.activeAudio = nil
		self.activeName = nil
		local audioPath = ModPath .. "audio/"
		if file.DirectoryExists(audioPath) and blt.xaudio then
			blt.xaudio.setup()
			local function setupBuffer(name, fileName)
				local fullPath = audioPath .. fileName
				if io.file_is_readable(fullPath) then
					self.buffers[name] = XAudio.Buffer:new(fullPath)
				end
			end
			
			setupBuffer("dominating", "Dominating.ogg")
			setupBuffer("doubleKill", "DoubleKill.ogg")
			setupBuffer("firstBlood", "FirstBlood.ogg")
			setupBuffer("godLike", "GodLike.ogg")
			setupBuffer("headHunter", "HeadHunter.ogg")
			setupBuffer("headShot", "HeadShot.ogg")
			setupBuffer("holyShit", "HolyShit.ogg")
			setupBuffer("holyShit2", "HolyShit2.ogg")
			setupBuffer("killingSpree", "KillingSpree.ogg")
			setupBuffer("ludicrousKill", "LudicrousKill.ogg")
			setupBuffer("megaKill", "MegaKill.ogg")
			setupBuffer("monsterKill", "MonsterKill.ogg")
			setupBuffer("monsterKill2", "MonsterKill2.ogg")
			setupBuffer("multiKill", "MultiKill.ogg")
			setupBuffer("rampage", "Rampage.ogg")
			setupBuffer("ultraKill", "UltraKill.ogg")
			setupBuffer("unstoppable", "Unstoppable.ogg")
			setupBuffer("wickedSick", "WickedSick.ogg")
		end
	end

	function UTAnnouncer:clearActive()
		self.activeAudio = nil
		self.activeName = nil
	end

	function UTAnnouncer:getActive()
		return self.activeAudio
	end

	function UTAnnouncer:queAndPlay(bufferName)
		if not self.settings.soundEnabled then return end
		local function priority(bufferName)
			local list = {
				["headShot"] = 0,
				["doubleKill"] = 1,
				["multiKill"] = 2,
				["megaKill"] = 3,
				["ultraKill"] = 4,
				["monsterKill"] = 5,
				["monsterKill2"] = 5,
				["ludicrousKill"] = 6,
				["holyShit"] = 7,
				["holyShit2"] = 7,
				["killingSpree"] = 8,
				["rampage"] = 9,
				["dominating"] = 10,
				["unstoppable"] = 11,
				["godLike"] = 12,
				["wickedSick"] = 13,
				["headHunter"] = 14,
				["firstBlood"] = 15
			}
			
			return list[bufferName] or 0
		end
		
		if self.activeAudio ~= nil then
			if priority(bufferName) > priority(self.activeName) then
				self.activeAudio:close()
			else
				return
			end
		end
		
		if self.buffers[bufferName] then
			self.activeAudio = XAudio.Source:new(self.buffers[bufferName])
			self.activeAudio:set_volume(UTAnnouncer.settings.volume or 1)
			self.activeName = bufferName
		end
	end

	Hooks:PostHook(GameSetup, "update", "UTAnnouncer:updateAudio", function(self, t, dt)
		local active = UTAnnouncer and UTAnnouncer:getActive()
		if active and active:is_closed() then
			UTAnnouncer:clearActive()
		end
	end)

	UTAnnouncer:setup()
end