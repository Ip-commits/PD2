local streak = 0
local headshotStreak = 0
local numKills = 0
local lastTime = nil
local chainTime = nil
local firstBlood = false
local streakLvl = 0

Hooks:PostHook(PlayerManager, "on_killshot", "UTAnnouncer:pmKillshot", function(self, killed_unit, variant, headshot, weapon_id)
	if not self:player_unit() or CopDamage.is_civilian(killed_unit:base()._tweak_table) then
		return
	end
	
	numKills = numKills + 1
	streak = streak + 1
	
	if headshot then
		headshotStreak = headshotStreak + 1
		if headshotStreak == 15 then
			UTAnnouncer:queAndPlay("headHunter")
			managers.hud:UTAnnouncerSetTextBottom("Head Hunter!")
		else
			UTAnnouncer:queAndPlay("headShot")
			managers.hud:UTAnnouncerSetTextBottom("Head Shot!")
		end
	end
	
	-- need to delay first blood check cause kill counters don't get updated in time
	if not firstBlood and managers.network and managers.network:session() and
	managers.statistics and managers.statistics:started_session_from_beginning() then
		DelayedCalls:Add("checkFirstBlood", 0.01, function()
			if managers.statistics:session_total_kills_by_anyone() == managers.statistics:session_total_kills() then
				UTAnnouncer:queAndPlay("firstBlood")
				managers.hud:UTAnnouncerSetTextBottom((managers.network.account:username() or "You") .. " drew first blood!", 24, Color("E30F21"))
			end
			firstBlood = true
		end)
	end
	
	lastTime = Application:time()
	chainTime = lastTime
end)

Hooks:PostHook(PlayerManager, "update", "UTAnnouncer:pmUpdate", function(self, t, dt)
	if lastTime and t - lastTime > 0.001 then
		-- Kill combos
		if numKills == 2 then
			UTAnnouncer:queAndPlay("doubleKill")
			managers.hud:UTAnnouncerSetTextTop("Double Kill!", 24)
		elseif numKills == 3 then
			UTAnnouncer:queAndPlay("multiKill")
			managers.hud:UTAnnouncerSetTextTop("Multi Kill!", 24)
		elseif numKills == 4 then
			UTAnnouncer:queAndPlay("megaKill")
			managers.hud:UTAnnouncerSetTextTop("Mega Kill!", 24)
		elseif numKills == 5 then
			UTAnnouncer:queAndPlay("ultraKill")
			managers.hud:UTAnnouncerSetTextTop("Ultra Kill!", 26)
		elseif numKills == 6 then
			if math.random() <= 0.1 then
				UTAnnouncer:queAndPlay("monsterKill2")
			else
				UTAnnouncer:queAndPlay("monsterKill")
			end
			managers.hud:UTAnnouncerSetTextTop("M O N S T E R  K I L L !!!", 28)
		elseif numKills == 7 then
			UTAnnouncer:queAndPlay("ludicrousKill")
			managers.hud:UTAnnouncerSetTextTop("L U D I C R O U S !!!", 28)
		elseif numKills >= 8 then
			if math.random() <= 0.1 then
				UTAnnouncer:queAndPlay("holyShit2")
			else
				UTAnnouncer:queAndPlay("holyShit")
			end
			managers.hud:UTAnnouncerSetTextTop("H O L Y  S H I T !", 28)
		end
		
		
		-- Kill Streaks
		if streakLvl <= 5 and streak >= 30 then
			UTAnnouncer:queAndPlay("wickedSick")
			managers.hud:UTAnnouncerSetTextBottom("WICKED SICK!")
			streakLvl = 6
		elseif streakLvl <= 4 and streak >= 25 then
			UTAnnouncer:queAndPlay("godLike")
			managers.hud:UTAnnouncerSetTextBottom("GODLIKE!")
			streakLvl = 5
		elseif streakLvl <= 3 and streak >= 20 then
			UTAnnouncer:queAndPlay("unstoppable")
			managers.hud:UTAnnouncerSetTextBottom("Unstoppable!")
			streakLvl = 4
		elseif streakLvl <= 2 and streak >= 15 then
			UTAnnouncer:queAndPlay("dominating")
			managers.hud:UTAnnouncerSetTextBottom("Dominating!")
			streakLvl = 3
		elseif streakLvl <= 1 and streak >= 10 then
			UTAnnouncer:queAndPlay("rampage")
			managers.hud:UTAnnouncerSetTextBottom("Rampage!")
			streakLvl = 2
		elseif streakLvl == 0 and streak >= 5 then
			UTAnnouncer:queAndPlay("killingSpree")
			managers.hud:UTAnnouncerSetTextBottom("Killing Spree!")
			streakLvl = 1
		end
		
		lastTime = nil
	end
	
	if chainTime and t - chainTime > 3 then
		numKills = 0
		chainTime = nil
	end
end)

function PlayerManager:UTAnnouncerResetStreak()
	streak = 0
	headshotStreak = 0
	streakLvl = 0
end