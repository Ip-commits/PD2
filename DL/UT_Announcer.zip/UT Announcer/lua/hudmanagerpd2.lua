Hooks:PostHook(HUDManager, "_setup_player_info_hud_pd2", "UTAnnouncer:infoHudInit", function(self)
	if not self:alive(PlayerBase.PLAYER_INFO_HUD_PD2) then
		return
	end

	local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_PD2)

	hud.panel:text({
		name = "UTAnnouncerTextTop",
		align = "center",
		visible = false,
		layer = 0,
		text = "",
		font = tweak_data.hud.medium_font
	})
	
	hud.panel:text({
		name = "UTAnnouncerTextBottom",
		align = "center",
		visible = false,
		layer = 0,
		text = "",
		font = tweak_data.hud.medium_font
	})
end)

function HUDManager:UTAnnouncerSetTextTop(text, size, color)
	if not UTAnnouncer.settings.textsEnabled then return end
	local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_PD2) 
	local textTop = hud and hud.panel and hud.panel:child("UTAnnouncerTextTop")
	size = (size or 24) * UTAnnouncer.settings.textScale
	color = color or Color("E30F21")
	if textTop  then
		textTop:set_font_size(size)
		textTop:set_text(text)
		textTop:set_color(color)
		local _, _, w, h = textTop:text_rect()
		textTop:set_size(w, h)
		textTop:set_center_x(hud.panel:w() * (UTAnnouncer.settings.textTopXPos or 0.5))
		textTop:set_center_y(hud.panel:h() * (UTAnnouncer.settings.textTopYPos or 0.15))
		textTop:set_visible(true)
		textTop:set_alpha(1)
		textTop:stop()
		textTop:animate(callback(self, self, "UTAnnouncerAnimateText"))
	end
end

function HUDManager:UTAnnouncerSetTextBottom(text, size, color)
	if not UTAnnouncer.settings.textsEnabled then return end
	local hud = managers.hud:script(PlayerBase.PLAYER_INFO_HUD_PD2) 
	local textBottom = hud and hud.panel and hud.panel:child("UTAnnouncerTextBottom")
	size = (size or 24) * UTAnnouncer.settings.textScale
	color = color or Color("1BB3E6")
	if textBottom  then
		textBottom:set_font_size(size)
		textBottom:set_text(text)
		textBottom:set_color(color)
		local _, _, w, h = textBottom:text_rect()
		textBottom:set_size(w, h)
		textBottom:set_center_x(hud.panel:w() * (UTAnnouncer.settings.textBottomXPos or 0.5))
		textBottom:set_center_y(hud.panel:h() * (UTAnnouncer.settings.textBottomYPos or 0.85))
		textBottom:set_visible(true)
		textBottom:set_alpha(1)
		textBottom:stop()
		textBottom:animate(callback(self, self, "UTAnnouncerAnimateText"))
	end
end

function HUDManager:UTAnnouncerAnimateText(text)
	local total = 5
	local t = 0
	while total > t do
		local dt = coroutine.yield()
		t = math.min(t + dt, total)
		
		local lerp = t / total
		if lerp > 0.25 then
			text:set_alpha(math.lerp(1, 0, lerp))
		end
	end
	textBottom:set_visible(false)
end
		