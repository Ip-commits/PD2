local me = managers.player and managers.player:local_player()
if me and alive(me) then
	local rot = me:movement():m_head_rot()
	local from = me:movement():m_head_pos() + rot:y() * 500
	local to = from + rot:y() * 1500
	local ray = me:raycast("ray", from, to, "slot_mask", managers.slot:get_mask("trip_mine_placeables"), "ignore_unit", {}, "ray_type", "equipment_placement")

	if ray then
		World:spawn_unit(Idstring("units/pd2_dlc_ranc/vehicles/fps_vehicle_golfcart/fps_vehicle_golfcart"), ray.position + math.UP * 20, Rotation(rot:yaw(), 0, 0))
	end
end