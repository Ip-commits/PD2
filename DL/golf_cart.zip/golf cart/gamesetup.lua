Hooks:PostHook(GameSetup, "load_packages", "GameSetup:loadVehicles", function(self)
	if not PackageManager:loaded("levels/narratives/mcshay/ranc/world/world") then
		PackageManager:load("levels/narratives/mcshay/ranc/world/world")
	end
end)