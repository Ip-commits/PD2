if not _G.BonkSFX then
	_G.BonkSFX = {}
	BonkSFX.soundPath = ModPath .. "sounds/bonk.ogg"
	BonkSFX.savePath = SavePath .. "BonkSFX.txt"
	BonkSFX.settings = {
		playersToggle = true,
		botsToggle = true,
		cloakerToggle = true,
		enemyToggle = true,
		hostageToggle = true,
		playersSync = true,
		playersVolume = 1,
		cloakerVolume = 0.75
	}
	for _, wpn in pairs(tweak_data.blackmarket.melee_weapons) do
		BonkSFX.settings[wpn.name_id] = true
	end

	function BonkSFX:unitPlayBonk(unit, volume)
		if self.bonk and unit and alive(unit) then
			local maxDist = 12000
			local me = managers.network:session() and managers.network:session():local_peer() and managers.network:session():local_peer():unit()
			if not me or not alive(me) then
				me = unit
			end
			
			local dist = math.min(mvector3.distance(me:position(), unit:position()), maxDist)
			local m = 1 - dist / maxDist
			XAudio.UnitSource:new(unit, self.bonk):set_volume(volume * m)
		end
	end

	function BonkSFX:init()
		if blt.xaudio and io.file_is_readable(self.soundPath) then
			blt.xaudio.setup()
			self.bonk = XAudio.Buffer:new(self.soundPath)
		end
	end

	function BonkSFX:load()
		local file = io.open(self.savePath, "r")
		if file then
			for k, v in pairs(json.decode(file:read("*all"))) do
				self.settings[k] = v
			end
			file:close()
		else
			self:save()
		end
	end

	function BonkSFX:save()
		local file = io.open(self.savePath, "w+")
		if file then
			file:write(json.encode(self.settings))
			file:close()
		end
	end
	
	NetworkHelper:AddReceiveHook("PlayBonkSound", "PlayBonkSoundHook", function(peer_id, sender)
		local unit = peer_id and managers.criminals:character_unit_by_peer_id(tonumber(peer_id))
		if unit and alive(unit) and BonkSFX.settings.playersSync then
			BonkSFX:unitPlayBonk(unit, BonkSFX.settings.playersVolume or 1)
		end
	end)
	
	Hooks:Add("MenuManagerInitialize", "BonkSFX:menuManagerInit", function()	
		BonkSFX:init()
		BonkSFX:load()
		
		Hooks:Add("MenuManagerSetupCustomMenus", "BonkSFX:setupCustomMenus", function()
			MenuHelper:NewMenu("BonkSFXMenu")
			MenuHelper:NewMenu("BonkSFXAdvancedSubMenu")
		end)
		
		Hooks:Add("MenuManagerPopulateCustomMenus", "BonkSFX:populateCustomMenus", function()
			-- Main Menu
			MenuHelper:AddToggle({
				id = "playersToggle",
				title = "locBonkSFXMenuPlayersTitle",
				desc = "locBonkSFXMenuPlayersDesc",
				callback = "cbBonkMenuToggle",
				menu_id = "BonkSFXMenu",
				value = BonkSFX.settings.playersToggle,
				priority = 7
			})
			
			MenuHelper:AddToggle({
				id = "playersSync",
				title = "locBonkSFXMenuPlayersSyncTitle",
				desc = "locBonkSFXMenuPlayersSyncDesc",
				callback = "cbBonkMenuToggle",
				menu_id = "BonkSFXMenu",
				value = BonkSFX.settings.playersSync,
				priority = 6
			})
			
			MenuHelper:AddToggle({
				id = "botsToggle",
				title = "locBonkSFXMenuBotsTitle",
				desc = "locBonkSFXMenuBotsDesc",
				callback = "cbBonkMenuToggle",
				menu_id = "BonkSFXMenu",
				value = BonkSFX.settings.botsToggle,
				priority = 5
			})
			
			MenuHelper:AddToggle({
				id = "cloakerToggle",
				title = "locBonkSFXMenuCloakerTitle",
				desc = "locBonkSFXMenuCloakerDesc",
				callback = "cbBonkMenuToggle",
				menu_id = "BonkSFXMenu",
				value = BonkSFX.settings.cloakerToggle,
				priority = 4
			})
			
			MenuHelper:AddToggle({
				id = "enemyToggle",
				title = "locBonkSFXMenuEnemiesTitle",
				desc = "locBonkSFXMenuEnemiesDesc",
				callback = "cbBonkMenuToggle",
				menu_id = "BonkSFXMenu",
				value = BonkSFX.settings.enemyToggle,
				priority = 3
			})
			
			MenuHelper:AddToggle({
				id = "hostageToggle",
				title = "locBonkSFXMenuHostageTitle",
				desc = "locBonkSFXMenuHostageDesc",
				callback = "cbBonkMenuToggle",
				menu_id = "BonkSFXMenu",
				value = BonkSFX.settings.hostageToggle,
				priority = 2
			})
			
			MenuHelper:AddSlider({
				id = "playersVolume",
				title = "locBonkSFXMenuPlayersVolTitle",
				desc = "locBonkSFXMenuPlayersVolDesc",
				callback = "cbBonkMenuSlider",
				value = BonkSFX.settings.playersVolume,
				min = 0,
				max = 1,
				display_scale = 100,
				display_precision = 0,
				step = 0.01,
				show_value = true,
				menu_id = "BonkSFXMenu",
				priority = 1
			})
			
			MenuHelper:AddSlider({
				id = "cloakerVolume",
				title = "locBonkSFXMenuCloakerVolTitle",
				desc = "locBonkSFXMenuCloakerVolDesc",
				callback = "cbBonkMenuSlider",
				value = BonkSFX.settings.cloakerVolume,
				min = 0,
				max = 1,
				display_scale = 100,
				display_precision = 0,
				step = 0.01,
				show_value = true,
				menu_id = "BonkSFXMenu",
				priority = 0
			})
			
			-- Submenu
			for _, wpn in pairs(tweak_data.blackmarket.melee_weapons) do
				local name = wpn.name_id
				MenuHelper:AddToggle({
					id = name,
					title = name,
					desc = "locBonkSFXMenuAdvencedSubTogglesDesc",
					callback = "cbBonkMenuToggle",
					menu_id = "BonkSFXAdvancedSubMenu",
					value = BonkSFX.settings[name]
				})
			end
		end)
		
		Hooks:Add("MenuManagerBuildCustomMenus", "BonkSFX:buildCustomMenus", function(menu_manager, nodes)
			nodes["BonkSFXMenu"] = MenuHelper:BuildMenu("BonkSFXMenu", {back_callback = "cbBonkSFXMenuBack"})
			MenuHelper:AddMenuItem(nodes.blt_options, "BonkSFXMenu", "locBonkSFXMenuTitle", "locBonkSFXMenuDesc")
			
			nodes["BonkSFXAdvancedSubMenu"] = MenuHelper:BuildMenu("BonkSFXAdvancedSubMenu", {back_callback = "cbBonkSFXMenuBack"})
			MenuHelper:AddMenuItem(nodes["BonkSFXMenu"], "BonkSFXAdvancedSubMenu", "locBonkSFXMenuAdvencedTogglesTitle", "locBonkSFXMenuAdvencedTogglesDesc")
		end)
		
	end)
	
	function MenuCallbackHandler:cbBonkMenuSlider(item)
		BonkSFX.settings[item:parameters().name] = math.min(math.max(tonumber(item:value()), 0), 1)
		BonkSFX:save()
	end
	
	function MenuCallbackHandler:cbBonkMenuToggle(item)
		BonkSFX.settings[item:parameters().name] = item:value() == "on"
		BonkSFX:save()
	end

	function MenuCallbackHandler:cbBonkSFXMenuBack()
		BonkSFX:save()
	end
end