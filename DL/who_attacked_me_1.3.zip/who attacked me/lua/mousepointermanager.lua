function MousePointerManager:suspendCallbacks()
	self:_deactivate()
end

function MousePointerManager:restoreCallbacks()
	self:_activate()
end
