if not _G.WhoAttackedMe then
	_G.WhoAttackedMe = {}
	WhoAttackedMe.save_path = SavePath .. "who_attacked_me.txt"
	WhoAttackedMe.path = ModPath
	-- Don't edit these settings, those are defaults.
	-- Edit messages in-game or edit the save file (only if you know what you're doing).
	WhoAttackedMe.settings = {
		mute_security_undominatable_on = false,
		mute_security_undominatable_msg = "Garrett downed me",
		heavy_swat_sniper_on = true,
		heavy_swat_sniper_msg = "Sniper!",
		sniper_on = true,
		sniper_msg = "Sniper!",
		mobster_boss_on = false,
		mobster_boss_msg = "Commissar got me",
		hector_boss_on = false,
		hector_boss_msg = "Hector got me",
		tank_green_on = true,
		tank_green_msg = "Bulldozer! (Green)",
		tank_black_on = true,
		tank_black_msg = "Bulldozer!",
		tank_skull_on = true,
		tank_skull_msg = "Skulldozer!",
		tank_hw_on = true,
		tank_hw_msg = "Bulldozer shot me",
		tank_medic_on = true,
		tank_medic_msg = "Medic dozer got me",
		tank_mini_on = true,
		tank_mini_msg = "Minigun Bulldozer!",
		medic_on = true,
		medic_msg = "Medic killed me",
		spooc_on = true,
		spooc_msg = "Cloaker shot me down",
		shield_on = true,
		shield_msg = "Shield downed me",
		phalanx_minion_on = true,
		phalanx_minion_msg = "Shield downed me",
		phalanx_vip_on = true,
		phalanx_vip_msg = "Winters downed me",
		taser_on = true,
		taser_msg = "Taser shot me",
		biker_boss_on = false,
		biker_boss_msg = "Biker boss killed me",
		chavez_boss_on = false,
		chavez_boss_msg = "Chavez downed me",
		drug_lord_boss_on = false,
		drug_lord_boss_msg = "Sosa destroyed me",
		triad_boss_on = true,
		triad_boss_msg = "Wang downed me",
		deep_boss_on = false,
		deep_boss_msg = "Gabriel got me",
		snowman_boss_on = true,
		snowman_boss_msg = "Snowman!",
		piggydozer_on = true,
		piggydozer_msg = "Piggydozer!",
		marshal_marksman_on = true,
		marshal_marksman_msg = "Marshal sniper shot me",
		marshal_shield_on = true,
		marshal_shield_msg = "Marshal shield got me",
		marshal_shield_break_on = true,
		marshal_shield_break_msg = "Marshal shield obliterated me",
		ranchmanager_on = false,
		ranchmanager_msg = "Esteban got me",
		cloakerIncap_on = true,
		cloakerIncap_msg = "Cloaker downed me",
		taserIncap_on = true,
		taserIncap_msg = "Taser downed me",
		taserZap_on = true,
		taserZap_msg = "Help! Taser",
		taserZap_delay = 3.5
	}
	
	function WhoAttackedMe:say(msg)
		if type(msg) ~= "string" or msg == "" then
			return
		end
		if managers.network:session() and managers.chat then
			managers.chat:send_message(ChatManager.GAME, managers.network.account:username() or "Player", msg)
		end
	end
	
	function WhoAttackedMe:load()
		local file = io.open(self.save_path, "r")
		if file then
			for k, v in pairs(json.decode(file:read("*all"))) do
				self.settings[k] = v
			end
			file:close()
		else
			self:save()
		end
	end

	function WhoAttackedMe:save()
		local file = io.open(self.save_path, "w+")
		if file then
			file:write(json.encode(self.settings))
			file:close()
		end
	end

	Hooks:Add("LocalizationManagerPostInit", "WhoAttackedMe:initLocalization", function(loc)
		loc:load_localization_file(WhoAttackedMe.path .. "loc/english.txt")
	end)

	Hooks:Add("MenuManagerInitialize", "WhoAttackedMe:init", function()
		WhoAttackedMe:load()		
		Hooks:Add("MenuManagerSetupCustomMenus", "WhoAttackedMe:setupCustomMenus", function()
			MenuHelper:NewMenu("WhoAttackedMeOptions")
		end)
		
		Hooks:Add("MenuManagerBuildCustomMenus", "WhoAttackedMe:buildCustomMenus", function(menu_manager, nodes)			
			local list = {
				"mute_security_undominatable",
				"heavy_swat_sniper",
				"sniper",
				"mobster_boss",
				"hector_boss",
				"tank_green",
				"tank_black",
				"tank_skull",
				"tank_hw",
				"tank_medic",
				"tank_mini",
				"medic",
				"spooc",
				"shield",
				"phalanx_minion",
				"phalanx_vip",
				"taser",
				"biker_boss",
				"chavez_boss",
				"drug_lord_boss",
				"triad_boss",
				"deep_boss",
				"snowman_boss",
				"piggydozer",
				"marshal_marksman",
				"marshal_shield",
				"marshal_shield_break",
				"ranchmanager"
			}

			table.sort(list, function(a, b)
				a = string.lower(managers.localization:text("locWhoAttackedMe_" .. a))
				b = string.lower(managers.localization:text("locWhoAttackedMe_" .. b))
				return b > a
			end)
			
			local function addInput(node, id, title, desc, callback, val, fSize)
				local input = MenuInitiatorBase:create_input(node, {
					localize = true,
					localize_help = true,
					enabled = true,
					name = id,
					text_id = title,
					help_id = desc,
					callback = callback,
					empty_gui_input_limit = 65,
					input_limit = 64,
					isCustomInput = true,
					fSize = fSize
				})
				
				if val ~= nil and val ~= "" then
					input:set_value(val)
				end
				return input
			end
			
			local function addToggle(node, id, title, desc, callback, val, fSize)
				local params = {
					localize = true,
					localize_help = true,
					enabled = true,
					name = id,
					text_id = title,
					help_id = desc,
					callback = callback,
					isCustomToggle = true,
					fSize = fSize
				}

				local data_node = {
					{
						w = 24,
						y = 0,
						h = 24,
						s_y = 24,
						value = "on",
						s_w = 24,
						s_h = 24,
						s_x = 24,
						_meta = "option",
						icon = "guis/textures/menu_tickbox",
						x = 24,
						s_icon = "guis/textures/menu_tickbox"
					},
					{
						w = 24,
						y = 0,
						h = 24,
						s_y = 24,
						value = "off",
						s_w = 24,
						s_h = 24,
						s_x = 0,
						_meta = "option",
						icon = "guis/textures/menu_tickbox",
						x = 0,
						s_icon = "guis/textures/menu_tickbox"
					},
					type = "CoreMenuItemToggle.ItemToggle"
				}
				local new_item = node:create_item(data_node, params)
				new_item:set_enabled(params.enabled)
				node:add_item(new_item)
				new_item:set_value(val and "on" or "off")
				return new_item
			end
			
			local function addSlider(node, id, title, desc, callback, val, min, max, step, precision, fSize)
				local data_node = {
					type = "CoreMenuItemSlider.ItemSlider",
					min = min or 1,
					max = max or 10,
					step = step or 1,
					show_value = val or false,
					decimal_count = precision or 0
				}
				
				local params = {
					name = id,
					text_id = title,
					help_id = desc,
					callback = callback,
					localize = true,
					localize_help = true,
					enabled = true,
					isCustomSlide = true,
					fSize = fSize
				}
				local new_item = node:create_item(data_node, params)
				node:add_item(new_item)
				
				if val ~= nil then
					new_item:set_value(val)
				end
				
				return new_item
			end
			
			local function addTitle(node, size, id, title, color, fSize)
				local params = {
					name = id,
					no_text = false,
					text_id = title,
					size = size or 8,
					color = color,
					fSize = fSize,
					isCustomTitle = true,
					localize = true
				}
				local data_node = {
					type = "MenuItemDivider"
				}
				local new_item = node:create_item(data_node, params)
				
				node:add_item(new_item)

				return new_item
			end
			
			local function addDiv(node, size, id, showLine)
				local params = {
					name = id,
					no_text = true,
					size = size,
					showLine = showLine or false
				}
				local data_node = {
					type = "MenuItemDivider"
				}
				local new_item = node:create_item(data_node, params)
				node:add_item(new_item)
				return new_item
			end
			
			local titleSize = 28
			local subTitleSize = 22
			local itemSize = 18
			local divSize = 12
			
			nodes["WhoAttackedMeOptions"] = MenuHelper:BuildMenu("WhoAttackedMeOptions")
			MenuHelper:AddMenuItem(nodes.blt_options, "WhoAttackedMeOptions", "locWhoAttackedMeOptionsTitle", "locWhoAttackedMeOptionsDesc")
			local node = nodes["WhoAttackedMeOptions"]
			local col1 = tweak_data.screen_colors.risk
			local col2 = tweak_data.screen_colors.text
			addTitle(node, titleSize, "titleSpecial", "locWhoAttackedMeSpecialAttacksTitle", col1, titleSize)
			addDiv(node, divSize, "div1", false)
			-- Cloaker Incap
			addTitle(node, subTitleSize, "titleCloakerIncap", "locWhoAttackedMe_cloakerIncap", col2, subTitleSize)
			addInput(node, "cloakerIncap_msg", "locWhoAttackedMeMsg", "locWhoAttackedMeMsgDescCloakerIncap", "cbWhoAttackedMeInputChange", WhoAttackedMe.settings.cloakerIncap_msg, itemSize)
			addToggle(node, "cloakerIncap_on", "locWhoAttackedMeEnabled", nil, "cbWhoAttackedMeToggle", WhoAttackedMe.settings.cloakerIncap_on, itemSize)
			addDiv(node, divSize, "div2", true)
			-- Taser Zap
			addTitle(node, subTitleSize, "titleTaserZap", "locWhoAttackedMe_taserZap", col2, subTitleSize)
			addInput(node, "taserZap_msg", "locWhoAttackedMeMsg", "locWhoAttackedMeMsgDescTaserZap", "cbWhoAttackedMeInputChange", WhoAttackedMe.settings.taserZap_msg, itemSize)
			addSlider(node, "taserZap_delay", "locWhoAttackedMe_taserZapLenTitle", "locWhoAttackedMe_taserZapLenDesc", "cbWhoAttackedMeSliderChange", WhoAttackedMe.settings.taserZap_delay, 1.5, 7, 0.5, 1, itemSize)
			addToggle(node, "taserZap_on", "locWhoAttackedMeEnabled", nil, "cbWhoAttackedMeToggle", WhoAttackedMe.settings.taserZap_on, itemSize)
			addDiv(node, divSize, "div3", true)
			-- Taser Incap
			addTitle(node, subTitleSize, "titleTaserIncap", "locWhoAttackedMe_taserIncap", col2, subTitleSize)
			addInput(node, "taserIncap_msg", "locWhoAttackedMeMsg", "locWhoAttackedMeMsgDescTaserIncap", "cbWhoAttackedMeInputChange", WhoAttackedMe.settings.taserIncap_msg, itemSize)
			addToggle(node, "taserIncap_on", "locWhoAttackedMeEnabled", nil, "cbWhoAttackedMeToggle", WhoAttackedMe.settings.taserIncap_on, itemSize)
			addDiv(node, 20, "div4", false)
			-- Shoot attacks
			addTitle(node, titleSize, "titleShot", "locWhoAttackedMeShootAttacksTitle", col1, titleSize)
			addDiv(node, divSize, "div5", false)
			for i, li in ipairs(list) do
				addTitle(node, subTitleSize, "title_" .. li, "locWhoAttackedMe_" .. li, col2, subTitleSize)
				addInput(node, li .. "_msg", "locWhoAttackedMeMsg", "locWhoAttackedMeMsgDescGeneric", "cbWhoAttackedMeInputChange", WhoAttackedMe.settings[li .. "_msg"], itemSize)
				addToggle(node, li .. "_on", "locWhoAttackedMeEnabled", nil, "cbWhoAttackedMeToggle", WhoAttackedMe.settings[li .. "_on"], itemSize)
				addDiv(node, divSize, "div_" .. li, i < #list)
			end
		end)
	end)
	
	function MenuCallbackHandler:cbWhoAttackedMeSliderChange(item)
		WhoAttackedMe.settings[item:parameters().name] = tonumber(item:value())
		WhoAttackedMe:save()
	end
	
	function MenuCallbackHandler:cbWhoAttackedMeToggle(item)
		WhoAttackedMe.settings[item:parameters().name] = item:value() == "on"
		WhoAttackedMe:save()
	end
	
	function MenuCallbackHandler:cbWhoAttackedMeInputChange(item)
		WhoAttackedMe.settings[item:parameters().name] = item:value() or ""
		WhoAttackedMe:save()
	end
	
	function MenuCallbackHandler:cbWhoAttackedMeOptionsBack()
		WhoAttackedMe:save()
	end
end