core:module("CoreMenuItemSlider")

local ogSize = nil
Hooks:PreHook(ItemSlider, "_layout", "WhoAttackedMe:preSetupSliderGui", function(self, node, row_item)
	if self.parameters and self:parameters().isCustomSlide then
		ogSize = node.font_size
		node.font_size = self:parameters().fSize or 18
	end
end)

Hooks:PostHook(ItemSlider, "_layout", "WhoAttackedMe:postSetupSliderGui", function(self, node, row_item)
	if self.parameters and self:parameters().isCustomSlide then
		node.font_size = ogSize or 24
	end
end)

Hooks:PostHook(ItemSlider, "setup_gui", "WhoAttackedMe:postSetUpSliderGui2", function(self, node, row_item)
	if self.parameters and self:parameters().isCustomSlide then
		row_item.gui_slider_text:set_font_size(self:parameters().fSize or 18)
	end
end)