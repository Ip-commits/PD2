local originalPlay = PlayerSound.play
function PlayerSound:play(sound_name, source_name, sync)
	if tostring(sound_name) == "bonk" then
		BonkSFX:unitPlayBonk(self._unit, BonkSFX.settings.playersVolume or 1)
		if sync then
			self._unit:network():send("unit_sound_play", SoundDevice:string_to_id("bonk"))
		end
	else
		originalPlay(self, sound_name, source_name, sync)
	end
end