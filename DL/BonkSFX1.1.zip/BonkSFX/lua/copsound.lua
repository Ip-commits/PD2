Hooks:PostHook(CopSound, "say", "BonkSFX:playCloakerStrike", function(self, sound_name, sync, skip_prefix, ...)
	if BonkSFX.settings.cloakerToggle and sound_name == "clk_punch_3rd_person_3p" and sync and skip_prefix and self._unit and alive(self._unit) then
		BonkSFX:unitPlayBonk(self._unit, BonkSFX.settings.cloakerVolume or 0.75)
	end
end)
