Hooks:PostHook(PlayerStandard, "init", "BonkSFX:makeUnitsHittable", function(self)
	self._slotmask_bullet_impact_targets = self._slotmask_bullet_impact_targets + 3 + 24
end)

Hooks:PostHook(PlayerStandard, "_calc_melee_hit_ray", "BonkSFX:meleeHit", function(self)
	local r = Hooks:GetReturn()
	if r and alive(r.unit) then
		local id = managers.blackmarket:equipped_melee_weapon()
		local wpnName = tweak_data.blackmarket.melee_weapons[id].name_id
		if BonkSFX.settings[wpnName] and ((BonkSFX.settings.playersToggle and r.unit:in_slot(3)) or
		(BonkSFX.settings.botsToggle and (r.unit:in_slot(16) or r.unit:in_slot(24))) or
		(BonkSFX.settings.hostageToggle and (r.unit:in_slot(21) or r.unit:in_slot(22))) or
		(BonkSFX.settings.enemyToggle and r.unit:in_slot(12))) then
			self._unit:sound():play("bonk", nil, true)
		end
	end
end)