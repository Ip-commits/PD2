function UnitNetworkHandler:unit_sound_play(unit, event_id, source, sender)
	if not alive(unit) or not self._verify_sender(sender) then
		return
	end

	if source == "" then
		source = nil
	end
	
	if event_id == -777 then
		if BonkSFX.settings.playersSync then
			BonkSFX:unitPlayBonk(unit, BonkSFX.settings.playersVolume or 1)
		end
	else
		unit:sound():play(event_id, source, false)
	end
end