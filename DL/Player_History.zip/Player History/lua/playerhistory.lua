if not Global.GLPlayerHistory then
	Global.GLPlayerHistory = {}
	local gph = Global.GLPlayerHistory
	gph.playerInfo = {}
	gph.config = {}
	
	local configPath = ModPath .. "json/config.json"
	local file = io.open(configPath, "r")
	if file then
		for k, v in pairs(json.decode(file:read("*all"))) do
			gph.config[k] = v
		end
		file:close()
	end
	
	if gph.config.serverPort then
		gph.baseURL = "http://localhost:" .. gph.config.serverPort .. "/history/"
	end
	
	local jsPath = ModPath .. "js/app.js"
	os.execute("start \"Player History\" node \"" .. jsPath:gsub("/", "\\") .. "\"")
end

_G.PlayerHistory = _G.PlayerHistory or {}
PlayerHistory.modPath = ModPath

function PlayerHistory:logAndDisplayErrorInChat(msg)
	if not msg then return end
	msg = string.format("Player History: %s", msg)
	log(msg)

	if managers.chat then
		managers.chat:feed_system_message(ChatManager.GAME, msg)
	end
end

function PlayerHistory:getHistoryURL()
	local gamePath = Application:base_path()
	return (gamePath .. PlayerHistory.modPath):gsub("\\", "/") .. "html/index.html"
end

function PlayerHistory:addPlayer(player_id, name, platform)
	local gph = Global.GLPlayerHistory
	local URL = gph.baseURL .. "playerEnter"
	local payloadContentType = "application/json"
	local headers = {Accept = "application/json"}
	local payloadBody = json.encode({
		player_id = player_id,
		name = name,
		platform = platform
	})
	
	if not URL or not payloadBody then return end
	local cb = function(errorCode, statusCode, responseBody)
		if errorCode == 0 then
			self:logAndDisplayErrorInChat("Unable to reach server")
		elseif errorCode == 1 then
			if statusCode == 500 then
				local decodedResponse = json.decode(responseBody)
				local msg = decodedResponse.message or "Error when adding player"
				self:logAndDisplayErrorInChat(msg)
			end
		end
	end
	HttpRequest:post(URL, cb, payloadContentType, payloadBody, headers)
end

function PlayerHistory:updatePlayerLastState(player_id, last_status)
	local gph = Global.GLPlayerHistory
	local URL = gph.baseURL .. "playerLeave"
	local payloadContentType = "application/json"
	local headers = {Accept = "application/json"}
	local payloadBody = json.encode({
		player_id = player_id,
		last_status = last_status
	})
	
	local cb = function(errorCode, statusCode, responseBody)
		if errorCode == 0 then
			self:logAndDisplayErrorInChat("Unable to reach server")
		elseif errorCode == 1 then
			if statusCode == 500 then
				local decodedResponse = json.decode(responseBody)
				local msg = decodedResponse.message or "Error when updating player info"
				self:logAndDisplayErrorInChat(msg)
			end
		end
	end
	
	if not URL or not payloadBody then return end
	HttpRequest:post(URL, cb, payloadContentType, payloadBody, headers)
end

function PlayerHistory:updateModRegistry(player_id, mods)
	if not mods then return end
	local gph = Global.GLPlayerHistory
	local URL = gph.baseURL .. "registerMods"
	
	
	local payloadContentType = "application/json"
	local headers = {Accept = "application/json"}
	local payloadBody = json.encode({
		player_id = player_id,
		mods = mods or {}
	})
	
	local cb = function(errorCode, statusCode, responseBody)
		if errorCode == 0 then
			self:logAndDisplayErrorInChat("Unable to reach server")
		elseif errorCode == 1 then
			if statusCode == 500 then
				local decodedResponse = json.decode(responseBody)
				local msg = decodedResponse.message or "Error when registering mods"
				self:logAndDisplayErrorInChat(msg)
			end
		end
	end
	
	if not URL or not payloadBody then return end
	HttpRequest:post(URL, cb, payloadContentType, payloadBody, headers)
end

Hooks:AddHook("NetworkManagerOnPeerAdded", "PlayerHistory:onPeerAdded", function(peer, peer_id)
	if not peer then return end
	local name = peer:name()
	local platform = peer:account_type_str()
	local player_id = peer:account_id()
	local gph = Global.GLPlayerHistory
	gph.playerInfo[player_id] = {}
	PlayerHistory:addPlayer(player_id, name, platform)
end)

-- When peer leaves the game, update their last status
Hooks:AddHook("BaseNetworkSessionOnPeerRemoved", "PlayerHistory:onPeerRemoved", function(peer, peer_id, reason)
	if not peer then return end
	if reason ~= "removed_dead" then
		PlayerHistory:updatePlayerLastState(peer:account_id(), reason or "unknown")
	end
	
	local gph = Global.GLPlayerHistory
	if gph and gph.playerInfo then
		gph.playerInfo[peer:account_id()] = nil
	end
end)

-- When you leave the game before other players, their state is set to unknown
-- Removes left over data from the Global table of players
Hooks:PostHook(MenuManager, "on_leave_lobby", "PlayerHistory:onLeaveLobby", function()
	local gph = Global.GLPlayerHistory
	for id in pairs(gph.playerInfo) do
		PlayerHistory:updatePlayerLastState(id, "unknown")
		gph.playerInfo[id] = nil
	end
end)

-- Runs when you quit the game, trough main menu. Tries to close the server and node app
Hooks:PreHook(MenuCallbackHandler, "_dialog_quit_yes", "PlayerHistory:onQuitGame", function()
	local gph = Global.GLPlayerHistory
	local URL = gph.baseURL .. "quitGame"
	if not URL then return end
	HttpRequest:post(URL, function() end, "application/json", "{}", {Accept = "application/json"})
end)

-- Add menu item to each peer
Hooks:PostHook(InspectPlayerInitiator, "modify_node", "PlayerHistory:inspectPlayer", function(self, node, inspect_peer)
	if not inspect_peer or inspect_peer == managers.network:session():local_peer() then return end
	
	local accID = inspect_peer:account_id()
	local gph = Global.GLPlayerHistory
	local gphPlayer = gph and gph.playerInfo and gph.playerInfo[accID]
	
	-- Check and register mods if they weren't scanned yet
	if gphPlayer and not gphPlayer.scanned then
		PlayerHistory:updateModRegistry(accID, inspect_peer:synced_mods())
		gphPlayer.scanned = true
	end
	
	local params = {
		callback = "cbPlayerHistoryInspect",
		text_id = "Player History",
		name = "playerHistoryInspect",
		localize = false,
		player_id = accID
	}
	
	local new_item = node:create_item(nil, params)
	node:insert_item(new_item, 2)
end)

function MenuCallbackHandler:cbPlayerHistoryInspect(item)
	local player_id = item and item.parameters and item:parameters().player_id
	if not player_id or not managers.network then return end
	managers.network.account:overlay_activate("url", PlayerHistory:getHistoryURL() .. "?tab=playerInfo&id=" .. player_id)
end