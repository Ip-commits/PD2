-- Add / update peer's mods to db, 2sec after syncing when in heist or briefing
Hooks:PostHook(BaseNetworkSession, "on_peer_sync_complete", "PlayerHistory:scanPeerMods", function(self, peer, peer_id)
	if not peer then return end
	local accID = peer:account_id()
	local gph = Global.GLPlayerHistory
	local gphPlayer = gph and gph.playerInfo and gph.playerInfo[accID]
	if not gphPlayer or gphPlayer.scanned then return end
	
	DelayedCalls:Add("PlayerHistoryScanMods_" .. tostring(accID), 2, function()
		if gphPlayer.scanned then return end
		for _, peer2 in pairs(managers.network:session():peers()) do
			if peer2:account_id() == accID then
				PlayerHistory:updateModRegistry(accID, peer2:synced_mods())
				gphPlayer.scanned = true
				break
			end
		end
	end)
end)