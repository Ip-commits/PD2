if _G.PlayerHistory and managers.network then
	managers.network.account:overlay_activate("url", PlayerHistory:getHistoryURL())
end