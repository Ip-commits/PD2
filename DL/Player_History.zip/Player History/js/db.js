const mysql = require('mysql2');
const config = require('../json/config.json');

const connection = mysql.createConnection({
	host: config.mysqlHost,
	user: config.mysqlUser,
	password: config.mysqlPassword,
	port: config.mysqlPort
});

// Connect to MySQL
connection.connect(async(err) => {
	if(err) {
		console.error('Error when connecting to MySQL');
		console.error(err.message);
		return;
	}
	
	const initTables = await initDbAndTables();
	if(!initTables.ok) {
		console.error('Error when initializing db and tables');
	}
});

// Create db and tables if they don't exist
async function initDbAndTables() {
	try {
		// create pd2_player_history database
		await new Promise((resolve, reject) => {
			const query = `CREATE DATABASE IF NOT EXISTS pd2_player_history DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci;`;
			connection.query(query, (err, result) => {
				if(err) reject(new Error(err.message));
				resolve(result);
			});
		});
		
		await new Promise((resolve, reject) => {
			const query = `USE pd2_player_history;`;
			connection.query(query, (err, result) => {
				if(err) reject(new Error(err.message));
				resolve(result);
			});
		});
		
		// create players table
		await new Promise((resolve, reject) => {
			const query = `CREATE TABLE IF NOT EXISTS players (
			player_id VARCHAR(32) NOT NULL,
			platform VARCHAR(5) NOT NULL,
			first_encounter DATETIME NOT NULL,
			last_encounter DATETIME NOT NULL,
			last_status VARCHAR(16) NOT NULL,
			PRIMARY KEY (player_id))
			ENGINE = InnoDB
			DEFAULT CHARACTER SET = utf8mb4
			COLLATE = utf8mb4_unicode_520_ci;`;
			connection.query(query, (err, result) => {
				if(err) reject(new Error(err.message));
				resolve(result);
			});
		});
		
		// create player_names table
		await new Promise((resolve, reject) => {
			const query = `CREATE TABLE IF NOT EXISTS player_names (
			player_id VARCHAR(32) NOT NULL,
			name VARCHAR(32) NOT NULL,
			date DATETIME NOT NULL,
			CONSTRAINT pk_playerNames PRIMARY KEY (player_id, name))
			ENGINE = InnoDB
			DEFAULT CHARACTER SET = utf8mb4
			COLLATE = utf8mb4_unicode_520_ci;`;
			connection.query(query, (err, result) => {
				if(err) reject(new Error(err.message));
				resolve(result);
			});
		});
		
		// create mods table
		await new Promise((resolve, reject) => {
			const query = `CREATE TABLE IF NOT EXISTS mods (
			mod_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
			mod_name VARCHAR(128) NOT NULL,
			dir_name VARCHAR(128) NOT NULL,
			PRIMARY KEY (mod_id),
			CONSTRAINT uk_mods UNIQUE KEY (mod_name, dir_name))
			ENGINE = InnoDB
			DEFAULT CHARACTER SET = utf8mb4
			COLLATE = utf8mb4_unicode_520_ci;`;
			connection.query(query, (err, result) => {
				if(err) reject(new Error(err.message));
				resolve(result);
			});
		});
		
		// create mod_history table
		await new Promise((resolve, reject) => {
			const query = `CREATE TABLE IF NOT EXISTS mod_history (
			player_id VARCHAR(32) NOT NULL,
			mod_id INT UNSIGNED NOT NULL,
			mod_state VARCHAR(10) NOT NULL,
			is_initial BOOL NOT NULL,
			change_date DATETIME NOT NULL,
			CONSTRAINT pk_modHistory PRIMARY KEY (player_id, mod_id),
			FOREIGN KEY(mod_id) REFERENCES mods(mod_id))
			ENGINE = InnoDB
			DEFAULT CHARACTER SET = utf8mb4
			COLLATE = utf8mb4_unicode_520_ci;`;
			connection.query(query, (err, result) => {
				if(err) reject(new Error(err.message));
				resolve(result);
			});
		});
		return {ok: true};
	} catch(err) {
		console.error(err);
		return {ok: false};
	}
}

let instance = null;
class Db {
	static getDbInstance() {
		instance = instance ? instance : new Db();
		return instance;
	}

	// Get player entry with specified id from players table
	async getPlayer(player_id) {
		try {
			const response = await new Promise((resolve, reject) => {
				const query = `SELECT player_id, platform, DATE_FORMAT(first_encounter, '${config.dateTimeFormat}') AS 'first_encounter', DATE_FORMAT(last_encounter, '${config.dateTimeFormat}') AS 'last_encounter', last_status FROM players WHERE player_id = ?;`;
				connection.query(query, [player_id], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});
			return {ok: true, response: response[0]};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	
	// Add new entry to players table
	async addNewPlayer(player_id, platform) {
		try {
			await new Promise((resolve, reject) => {
				const date = new Date();
				const query = `INSERT INTO players (player_id, platform, first_encounter, last_encounter, last_status) VALUES (?, ?, ?, ?, 'enter');`;
				connection.query(query, [player_id, platform, date, date], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});
			return await this.getPlayer(player_id);
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	
	
	// Update player entry
	async updatePlayer(player_id, last_status) {
		try {
			await new Promise((resolve, reject) => {
				if(!last_status) last_status = 'unknown';
				const date = new Date();
				const query = `UPDATE players SET last_encounter = ?, last_status = ? WHERE player_id = ?;`;
				connection.query(query, [date, last_status, player_id], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});
			return {ok: true};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
		
	// Check if name entry exists for player with specified id
	async nameExists(player_id, name) {
		try {
			const response = await new Promise((resolve, reject) => {
				const query = `SELECT * FROM player_names WHERE player_id = ? AND name = ?;`;
				connection.query(query, [player_id, name], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});
			return {ok: true, response: response[0] === undefined ? false : true};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	
	
	// Add new name to player_names for a player with specified id
	async addNewName(player_id, name) {
		try {
			await new Promise((resolve, reject) => {
				const date = new Date();
				const query = `INSERT INTO player_names (player_id, name, date) VALUES (?, ?, ?);`;
				connection.query(query, [player_id, name, date], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});
			return {ok: true};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	
	// Update name date in player_names for a player with specified id
	async updateNameDate(player_id, name) {
		try {
			await new Promise((resolve, reject) => {
				const date = new Date();
				const query = `UPDATE player_names SET date = ? WHERE player_id = ? AND name = ?;`;
				connection.query(query, [date, player_id, name], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});
			return {ok: true};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	

	// Get names of player with specified id, return array
	async getNamesArr(player_id, orderBy = 'date', order = 'DESC') {
		try {
			const response = await new Promise((resolve, reject) => {
				const query = `SELECT name, DATE_FORMAT(date, '${config.dateTimeFormat}') AS date FROM player_names WHERE player_id = ? ORDER BY ${orderBy} ${order};`;
				connection.query(query, [player_id], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});
			
			return {ok: true, response: response};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	
	// Get names of player with specified id, return string
	async getNamesStr(player_id, orderBy = 'date', order = 'DESC', separator = ', ') {
		try {
			const response = await new Promise((resolve, reject) => {
				const query = `SELECT player_id, GROUP_CONCAT(name ORDER BY ${orderBy} ${order} SEPARATOR '${separator}') AS names FROM player_names WHERE player_id = ? GROUP BY player_id;`;
				connection.query(query, [player_id], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});
			
			return {ok: true, response: response[0] === undefined ? '' : response[0].names};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	
	// Get id of mod in mods table or -1 if not exists
	async getModId(mod_name, dir_name) {
		try {
			const response = await new Promise((resolve, reject) => {
				const query = `SELECT mod_id FROM mods WHERE mod_name = ? AND dir_name = ?;`;
				connection.query(query, [mod_name, dir_name], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});
			
			return {ok: true, response: response[0] === undefined ? -1 : response[0].mod_id};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	
	// Add new mod to mods table
	async addNewMod(mod_name, dir_name) {
		try {
			const response = await new Promise((resolve, reject) => {
				const query = `INSERT INTO mods (mod_name, dir_name) VALUES (?, ?);`;
				connection.query(query, [mod_name, dir_name], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result.insertId);
				});
			});
			return {ok: true, response: response};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	
	// Add new entry to mod_history table
	async addNewModHistory(player_id, mod_id, mod_state, is_initial) {
		try {
			await new Promise((resolve, reject) => {
				const date = new Date();
				const query = `INSERT INTO mod_history (player_id, mod_id, mod_state, is_initial, change_date) VALUES (?, ?, ?, ?, ?);`;
				connection.query(query, [player_id, mod_id, mod_state, is_initial, date], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result.insertId);
				});
			});
			return {ok: true};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	
	// Update mod_history state
	async updateModHistoryState(player_id, mod_id, mod_state) {
		try {
			await new Promise((resolve, reject) => {
				const date = new Date();
				const query = `UPDATE mod_history SET mod_state = ?, change_date = ? WHERE player_id = ? AND mod_id = ?;`;
				connection.query(query, [mod_state, date, player_id, mod_id], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result.insertId);
				});
			});
			return {ok: true};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	
	// Get player's mod history
	async getModHistory(player_id) {
		try {
			const response = await new Promise((resolve, reject) => {
				const query = `SELECT mods.mod_name, mods.dir_name, mod_history.mod_state, mod_history.is_initial, mod_history.mod_id,
				DATE_FORMAT(mod_history.change_date, '${config.dateTimeFormat}') AS change_date
				FROM mod_history
				INNER JOIN mods ON mod_history.mod_id=mods.mod_id AND mod_history.player_id=? ORDER BY mods.mod_name ASC;`;
				connection.query(query, [player_id], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});

			return {ok: true, response: response};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
	
	// Get an array of players we last played with, sorted by date newest to oldest
	async getLastPlayedWith(page) {
		try {
			// get total number of player entries
			const [total] = await new Promise((resolve, reject) => {
				const query = `SELECT COUNT(player_id) AS count FROM players;`;
				connection.query(query, (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});
			
			const rowsPerPage = Math.max(1, parseInt(config.playHistoryRowsPerPage) || 50);
			const maxPages = Math.max(1, Math.ceil(total.count / rowsPerPage));
			page = Math.min(Math.max(1, parseInt(page) || 1), maxPages);
			const skip = (page - 1) * rowsPerPage;
			
			const response = await new Promise((resolve, reject) => {
				const query = `SELECT players.player_id, last_names.name, players.last_status, players.platform, DATE_FORMAT(players.last_encounter, '${config.dateTimeFormat}') AS last_encounter
				FROM players
				INNER JOIN (SELECT n1.player_id, n1.name FROM player_names AS n1
				INNER JOIN (SELECT player_id, MAX(date) AS md FROM player_names GROUP BY player_id) AS n2
				ON n1.player_id = n2.player_id AND n1.date = n2.md) AS last_names ON players.player_id = last_names.player_id
				ORDER BY players.last_encounter DESC, last_names.name ASC
				LIMIT ?, ?;`;
				connection.query(query, [skip, rowsPerPage], (err, result) => {
					if(err) reject(new Error(err.message));
					resolve(result);
				});
			});
			
			return {ok: true, response: response, maxPages: maxPages};
		} catch(err) {
			console.error(err);
			return {ok: false};
		}
	}
}

module.exports.dbService = Db;
module.exports.connection = connection;