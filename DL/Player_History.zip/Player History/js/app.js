const express = require('express');
const app = express();
const cors = require('cors');
const config = require('../json/config.json');
const {dbService, connection} = require('./db');

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended: false}));

// Runs when a player joins. Adds them to the database if their info doesn't exist
// or updates their last_encounter date and potential name changes if they already exist
app.post('/history/playerEnter', async(request, response) => {
	const {player_id, name, platform} = request.body;
	const db = dbService.getDbInstance();
	
	// Check if player alredy exists and get entry, if not create a new entry
	let entry = await db.getPlayer(player_id);	
	if(!entry.ok) {
		response.status(500).json({message: 'Error while checking player data'});
		return;
	}
	
	if(entry.response === undefined) {
		// Player doesn't exist in db, add new entry
		entry = await db.addNewPlayer(player_id, platform);
		if(!entry.ok) {
			response.status(500).json({message: 'Error while adding player data'});
			return;
		}
	} else {
		// Player exists, update entry
		const updatePlayerEntry = await db.updatePlayer(player_id, 'enter');
		if(!updatePlayerEntry.ok) {
			response.status(500).json({message: 'Error while updating player data'});
			return;
		}
	}
	
	// Check if name exists in db
	const nameExists = await db.nameExists(player_id, name);
	if(!nameExists.ok) {
		response.status(500).json({message: 'Error while checking player name'});
		return;
	}
	
	if(!nameExists.response) {
		// Name doesn't exist, add a new entry
		const newNameAdded = await db.addNewName(player_id, name);
		if(!newNameAdded.ok) {
			response.status(500).json({message: 'Error while adding player name'});
			return;
		}
	} else {
		// Name exists, update old entry date
		const updateNameDate = await db.updateNameDate(player_id, name);
		if(!updateNameDate.ok) {
			response.status(500).json({message: 'Error while updating player name data'});
			return;
		}
	}
	
	response.status(200).json({first_encounter: entry.response.first_encounter, last_encounter: entry.response.last_encounter, last_status: entry.response.last_status});
});

// Runs when player leaves or gets kicked, update their last status
app.post('/history/playerLeave', async(request, response) => {
	const {player_id, last_status} = request.body;
	const db = dbService.getDbInstance();
	const update = await db.updatePlayer(player_id, last_status);
	if(!update.ok) {
		response.status(500).json({message: 'Error while updating player data'});
		return;
	}
	response.status(200).json({message: 'OK'});
});

// Runs when scanning player's mods
// Adds new mods to mods table and updates player's mod_history table
app.post('/history/registerMods', async(request, response) => {
	const {player_id, mods} = request.body;	
	const db = dbService.getDbInstance();
	
	// Add mods fetched from the game to mods table if they don't exist in db
	// then get mod ids from db and append them to the mods array
	let i, current, modId, addNewMod;
	for(i in mods) {
		current = mods[i];
		modId = await db.getModId(current.name, current.id);
		if(!modId.ok) {
			response.status(500).json({message: 'Error while checking mods table'});
			return;
		}
		
		if(modId.response === -1) {
			addNewMod = await db.addNewMod(current.name, current.id);
			if(!addNewMod.ok) {
				response.status(500).json({message: 'Error while adding mod to mods table'});
				return;
			}
			current.mod_id = addNewMod.response;
		} else {
			current.mod_id = modId.response;
		}
	}
	
	// Get player's data from db to check if they're a new player or not
	const playerInfo = await db.getPlayer(player_id);
	if(!playerInfo.ok || playerInfo.response === undefined) {
		response.status(500).json({message: 'Error while getting player data'});
		return;
	}
	
	// Get player's mod history from db
	const getModHistory = await db.getModHistory(player_id);
	if(!getModHistory.ok) {
		response.status(500).json({message: 'Error while getting player\'s mod history'});
		return;
	}
	
	// if the player's first and last encounter dates match, initial mod state is 1 (true), else it's 0 (false)
	const is_initial = playerInfo.response.first_encounter == playerInfo.response.last_encounter ? 1 : 0;
	
	const map = new Map();
	const removedCheck = new Set(); // Used to check difference between db and game mods to find which mods were removed
	let key, val, modHistory;
	
	// data from db
	for(i in getModHistory.response) {
		current = getModHistory.response[i];
		key = current.mod_name + '|' + current.dir_name;
		map.set(key, {mod_name: current.mod_name, dir_name: current.dir_name, mod_state: current.mod_state, mod_id: current.mod_id});
		removedCheck.add(key); // add all keys to the set
	}
	
	// data from game
	for(i in mods) {
		current = mods[i];
		key = current.name + '|' + current.id;
		removedCheck.delete(key); // don't need this key, remove value from the set
		if(map.has(key)) {
			// Not a new mod
			val = map.get(key);
			if(val.mod_state == 'removed') {
				val.mod_state = 'readded';
				map.set(key, val);
				modHistory = await db.updateModHistoryState(player_id, val.mod_id, val.mod_state);
				if(!modHistory.ok) {
					response.status(500).json({message: 'Error while updating mod_history data'});
					return;
				}
			}
		} else {
			// New mod
			modHistory = await db.addNewModHistory(player_id, current.mod_id, 'added', is_initial);
			if(!modHistory.ok) {
				response.status(500).json({message: 'Error while adding data to mod_history table'});
				return;
			}
		}
	}
	
	// removed mods
	let errors = false;
	removedCheck.forEach(async(key) => {
		val = map.get(key);
		if(val.mod_state != 'removed') {
			val.mod_state = 'removed';
			modHistory = await db.updateModHistoryState(player_id, val.mod_id, val.mod_state);
			if(!modHistory.ok) {
				errors = true;
				return;
			}
		}
	});
	
	if(errors) {
		response.status(500).json({message: 'Error while updating mod_history data'});
		return;
	}
	
	response.status(200).json({message: 'OK'});
});

// fetch player data
app.get('/history/playerData/:player_id', async(request, response) => {
	const player_id = request.params.player_id;
	const db = dbService.getDbInstance();
	
	const getPlayer = await db.getPlayer(player_id);
	if(!getPlayer.ok) {
		response.status(500).json({message: 'Error fetching data from server.'});
		return;
	}
	
	if(getPlayer.response === undefined) {
		response.status(404).json({message: 'Player not found.'});
		return;
	}
	
	const playerNames = await db.getNamesArr(player_id);
	if(!playerNames.ok) {
		response.status(500).json({message: 'Error fetching data from server.'});
		return;
	}
	
	const mods = await db.getModHistory(player_id);
	if(!mods.ok) {
		response.status(500).json({message: 'Error fetching data from server.'});
		return;
	}
	
	response.status(200).json({playerInfo: getPlayer.response, names: playerNames.response, mods: mods.response});
});

app.get('/history/lastPlayed', async(request, response) => {
	const {page} = request.query;
	const db = dbService.getDbInstance();
	const lastPlayedWith = await db.getLastPlayedWith(page);
	if(!lastPlayedWith.ok) {
		response.status(500).json({message: 'Error fetching data from server.'});
		return;
	}
	
	response.status(200).json({rows: lastPlayedWith.response, maxPages: lastPlayedWith.maxPages});
});

const server = app.listen(config.serverPort, () => {
	console.log(`Server is running on http://localhost:${config.serverPort}`);
});

server.on('error', (error) => {
	if (error.code === 'EADDRINUSE') {
		console.error(`Port ${config.serverPort} is already in use`);
	}
});

// Close server and mysql connection
app.post('/history/quitGame', async(request, response) => {
	server.close(() => {
		console.log('Shutting down server...');
		connection.end((error) => {
			if (error) {
				console.error('Error closing MySQL connection:', error);
				return;
			}
		});
		process.exit(0);
	});
	response.status(200).json({message: 'OK'});
});