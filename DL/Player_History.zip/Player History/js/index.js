const serverUrl = 'http://localhost:3085';

document.addEventListener('DOMContentLoaded', () => {
	const urlParams = new URLSearchParams(window.location.search);
	const tab = urlParams.get('tab');
	const page = urlParams.get('page');
	
	switch(tab) {
		case 'modsOverview':
			showModsOverview();
			break;
		case 'playerInfo':
			showPlayerInfo(urlParams.get('id'));
			break;
		default:
			showLastPlayedWith(page);
	}
});

function showLastPlayedWith(page) {
	fetch(serverUrl + '/history/lastPlayed?page=' + page)
	.then(response => {
		if(!response.ok) {
			return response.json().then(data => {throw new Error(data.message)});
		}
		return response.json();
	})
	.then(data => createLastPlayedWithTable(data))
	.catch(err => displayErrorMsg('ERROR', err.message));
}

function showModsOverview() {
	const contentDiv = document.querySelector('#content');
	contentDiv.innerHTML = '<p>MODS</p>';
}

function showPlayerInfo(id) {
	const menuDiv = document.querySelector('#menu');
	menuDiv.innerHTML = '<a href="index.html">Play history</a>';
	
	fetch(serverUrl + '/history/playerData/' + id)
	.then(response => {
		if(!response.ok) {
			return response.json().then(data => {throw new Error(data.message)});
		}
		return response.json();
	})
	.then(data => createPlayerInfoTables(data))
	.catch(err => displayErrorMsg('Error', err.message));
}

function createPlayerInfoTables(data) {	
	const contentDiv = document.querySelector('#content');
	let nameDate = data.names.shift();
	let html = '<h1>Player info</h1>';
	html += '<table class="dataTable dataTableTh1">';
	html += '<tr>';
	html += '<th>Player ID</th>';
	html += '<th>Name</th>';
	html += '<th>Account type</th>';
	html += '</tr>';
	html += '<tr>';
	html += `<td>${data.playerInfo.player_id}</td>`;
	html += `<td>${nameDate.name}</td>`;
	html += `<td>${data.playerInfo.platform}</td>`;
	html += '</tr>';
	html += '<tr>';
	html += '<th>Last status</th>';
	html += '<th>First seen</th>';
	html += '<th>Last seen</th>';
	html += '</tr>';
	html += '<tr>';
	html += `<td>${data.playerInfo.last_status}</td>`;
	html += `<td>${data.playerInfo.first_encounter}</td>`;
	html += `<td>${data.playerInfo.last_encounter}</td>`;
	html += '</tr>';
	if(data.names.length > 0) {
		html += '<tr>';
		html += '<th colspan="2">Other names</th>';
		html += '<th>Other name seen</th>';
		html += '</tr>';
		data.names.forEach(nameDate => {
			html += `<tr><td colspan="2">${nameDate.name}</td><td>${nameDate.date}</td></tr>`;
		});
	}
	html += '</table>';
	
	html += '<h1>Mods</h1>';
	html += '<table class="dataTable dataTableTh1">';
	if(data.mods.length == 0) {
		html += '<tr><td>No mods on record.</td></tr>';
	} else {
		html += '<tr>';
		html += '<th>Initial</th>';
		html += '<th>Mod name / directory</th>';
		html += '<th>Status</th>';
		html += '<th>Change date</th>';
		html += '</tr>';
		data.mods.forEach(mod => {
			html += '<tr>';
			html += `<td>${mod.is_initial == 1 ? '&#9745;' : '&#9744;'}</td>`;
			html += '<td>';
			html += '<ul>';
			html += `<li>${mod.mod_name}</li>`;
			if(mod.dir_name != mod.mod_name)
				html += `<li class="secCol">${mod.dir_name}</li>`;
			html += '</ul>';
			html += '</td>';
			html += `<td>${mod.mod_state}</td>`;
			html += `<td>${mod.change_date}</td>`;
			html += '</tr>';
		});
	}
	html += '</table>';
	contentDiv.innerHTML = html;
}

function createLastPlayedWithTable(data) {
	const contentDiv = document.querySelector('#content');
	let html = '<h1>Play History</h1>';
	html += '<table class="dataTable dataTableTh1">';
	if(data.rows.length == 0) {
		html += '<tr><td>No records found.</td></tr>';
	} else {
		html += '<tr>';
		html += '<th>Name</th>';
		html += '<th>Player ID</th>';
		html += '<th>Account type</th>';
		html += '<th>Status</th>';
		html += '<th>Last seen</th>';
		html += '<th>Mods / Info</th>';
		html += '</tr>';
		data.rows.forEach(item => {
			html += '<tr>';
			html += `<td class="noTextTransform">${item.name}</td>`;
			html += `<td>${item.player_id}</td>`;
			html += `<td>${item.platform}</td>`;
			html += `<td>${item.last_status}</td>`;
			html += `<td>${item.last_encounter}</td>`;
			html += `<td><a href="index.html?tab=playerInfo&id=${item.player_id}">Player Info</a></td>`;
			html += '</tr>';
		});
	}
	html += '</table>';
	if(data.maxPages > 1) {
		html += addPageSelect(data.maxPages);
	}
	contentDiv.innerHTML = html;
}

function addPageSelect(maxPages) {
	const urlParams = new URLSearchParams(window.location.search);
	const page = parseInt(urlParams.get('page')) || 1;
	
	let html = '<div class="pageSelect">';
	if(page > 1) {
		urlParams.set('page', 1);
		html += `<a href="index.html${'?' + urlParams.toString()}"><< First</a>`;
		urlParams.set('page', page - 1);
		html += `<a href="index.html${'?' + urlParams.toString()}">< Prev</a>`;
	} else {
		html += '<span></span>';
		html += '<span></span>';
	}
	
	if(maxPages > 1) {
		html += `<input type="number" min="1" max="${maxPages}" step="1" value="${page}" onchange="jumpToPage(this, ${maxPages});">`;
	}
	
	if(page < maxPages) {
		urlParams.set('page', page + 1);
		html += `<a href="index.html${'?' + urlParams.toString()}">Next ></a>`;
		urlParams.set('page', maxPages);
		html += `<a href="index.html${'?' + urlParams.toString()}">Last >></a>`;
	} else {
		html += '<span></span>';
		html += '<span></span>';
	}
	html += '</div>';
	return html;
}

function displayErrorMsg(title, text) {
	const contentDiv = document.querySelector('#content');
	let html = `<h1>${title}</h1>`;
	html += `<p>${text}</p>`;
	contentDiv.innerHTML = html;
}

function jumpToPage(input, maxPages) {
	console.log("CHANGE");
	const urlParams = new URLSearchParams(window.location.search);
	urlParams.set('page', Math.min(Math.max(input.value, 1), maxPages));
	window.location.href = `index.html?${urlParams.toString()}`;
}