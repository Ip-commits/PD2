Hooks:PostHook(ActionSpooc, "anim_act_clbk", "BonkSFX:cloaker", function(self, anim_act)
	if BonkSFX.settings.cloakerToggle and anim_act == "strike" and self._unit and alive(self._unit) then
		BonkSFX:unitPlayBonk(self._unit, BonkSFX.settings.cloakerVolume)
	end
end)
