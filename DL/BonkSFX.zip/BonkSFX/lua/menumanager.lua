if not _G.BonkSFX then
	_G.BonkSFX = {}
	BonkSFX.soundPath = ModPath .. "sounds/bonk.ogg"
	BonkSFX.menuItemsPath = ModPath .. "menu/options.txt"
	BonkSFX.savePath = SavePath .. "BonkSFX.txt"
	BonkSFX.settings = {
		playersToggle = true,
		botsToggle = true,
		cloakerToggle = true,
		enemyToggle = true,
		hostageToggle = true,
		playersVolume = 1,
		cloakerVolume = 0.75
	}
	for _, wpn in pairs(tweak_data.blackmarket.melee_weapons) do
		BonkSFX.settings[wpn.name_id] = true
	end

	function BonkSFX:unitPlayBonk(unit, volume)
		if self.bonk and unit and (unit == XAudio.PLAYER or alive(unit)) then
			XAudio.UnitSource:new(unit, self.bonk):set_volume(volume)
		end
	end

	function BonkSFX:init()
		if blt.xaudio and io.file_is_readable(self.soundPath) then
			blt.xaudio.setup()
			self.bonk = XAudio.Buffer:new(self.soundPath)
		end
	end

	function BonkSFX:load()
		local file = io.open(self.savePath, "r")
		if file then
			for k, v in pairs(json.decode(file:read("*all"))) do
				self.settings[k] = v
			end
			file:close()
		else
			self:save()
		end
	end

	function BonkSFX:save()
		local file = io.open(self.savePath, "w+")
		if file then
			file:write(json.encode(self.settings))
			file:close()
		end
	end

	Hooks:Add("MenuManagerInitialize", "BonkSFX:menuManagerInit", function()	
		BonkSFX:init()
		BonkSFX:load()
		MenuHelper:LoadFromJsonFile(BonkSFX.menuItemsPath, BonkSFX, BonkSFX.settings)
		
		Hooks:Add("MenuManagerSetupCustomMenus", "BonkSFX:setupCustomMenus", function()
			MenuHelper:NewMenu("BonkSFXAdvancedSubMenu")
		end)
		
		Hooks:Add("MenuManagerPopulateCustomMenus", "BonkSFX:populateCustomMenus", function()
			for _, wpn in pairs(tweak_data.blackmarket.melee_weapons) do
				local name = wpn.name_id
				MenuHelper:AddToggle({
					id = "BonkSFXAdvanced_" .. name,
					title = name,
					desc = "locBonkSFXMenuAdvencedSubTogglesDesc",
					callback = "cbBonkSFXAdvanced",
					value = BonkSFX.settings[name],
					menu_id = "BonkSFXAdvancedSubMenu"
				})
			end
		end)
		
		Hooks:Add("MenuManagerBuildCustomMenus", "BonkSFX:buildCustomMenus", function(menu_manager, nodes)
			nodes["BonkSFXAdvancedSubMenu"] = MenuHelper:BuildMenu("BonkSFXAdvancedSubMenu", {back_callback = "cbBonkSFXMenuBack"})
			MenuHelper:AddMenuItem(MenuHelper:GetMenu("BonkSFXMenu"), "BonkSFXAdvancedSubMenu", "locBonkSFXMenuAdvencedTogglesTitle", "locBonkSFXMenuAdvencedTogglesDesc")
		end)
		
	end)
	
	function MenuCallbackHandler:cbBonkSFXAdvanced(item)	
		BonkSFX.settings[item:parameters().text_id] = item:value() == "on"
		BonkSFX:save()
	end

	function MenuCallbackHandler:cbBonkSFXMenuBack()
		BonkSFX:save()
	end

	function MenuCallbackHandler:cbBonkSFXTogglePlayers(item)
		BonkSFX.settings.playersToggle = item:value() == "on"
		BonkSFX:save()
	end

	function MenuCallbackHandler:cbBonkSFXVolumePlayers(item)
		BonkSFX.settings.playersVolume = math.min(math.max(tonumber(item:value()), 0), 1)
		BonkSFX:save()
	end

	function MenuCallbackHandler:cbBonkSFXVolumeCloaker(item)
		BonkSFX.settings.cloakerVolume = math.min(math.max(tonumber(item:value()), 0), 1)
		BonkSFX:save()
	end

	function MenuCallbackHandler:cbBonkSFXToggleBots(item)
		BonkSFX.settings.botsToggle = item:value() == "on"
		BonkSFX:save()
	end

	function MenuCallbackHandler:cbBonkSFXToggleCloaker(item)
		BonkSFX.settings.cloakerToggle = item:value() == "on"
		BonkSFX:save()
	end
	
	function MenuCallbackHandler:cbBonkSFXToggleHostages(item)
		BonkSFX.settings.hostageToggle = item:value() == "on"
		BonkSFX:save()
	end

	function MenuCallbackHandler:cbBonkSFXToggleEnemies(item)
		BonkSFX.settings.enemyToggle = item:value() == "on"
		BonkSFX:save()
	end
end