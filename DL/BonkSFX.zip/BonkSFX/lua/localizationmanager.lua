Hooks:Add("LocalizationManagerPostInit", "BonkSFX:localizationInit", function(loc)
	loc:add_localized_strings({
		["locBonkSFXMenuTitle"] = "Bonk SFX",
		["locBonkSFXMenuDesc"] = "Options for bonk sound effects",
		["locBonkSFXMenuPlayersTitle"] = "Hittable players",
		["locBonkSFXMenuPlayersDesc"] = "Play sound when hitting other players",
		["locBonkSFXMenuPlayersVolTitle"] = "Volume",
		["locBonkSFXMenuPlayersVolDesc"] = "Volume level of your bonks",
		["locBonkSFXMenuBotsTitle"] = "Hittable bots / jokers",
		["locBonkSFXMenuBotsDesc"] = "Play sound when hitting bots and jokers",
		["locBonkSFXMenuEnemiesTitle"] = "Hittable enemies",
		["locBonkSFXMenuEnemiesDesc"] = "Play sound when hitting enemies",
		["locBonkSFXMenuHostageTitle"] = "Hittable hostages",
		["locBonkSFXMenuHostageDesc"] = "Play sound when hitting hostages",
		["locBonkSFXMenuCloakerTitle"] = "Cloakers can bonk",
		["locBonkSFXMenuCloakerDesc"] = "Play sound when cloakers hit somebody",
		["locBonkSFXMenuCloakerVolTitle"] = "Cloaker Volume",
		["locBonkSFXMenuCloakerVolDesc"] = "Volume level of cloaker's bonks",
		["locBonkSFXMenuAdvencedTogglesTitle"] = "Advanced - Individual weapon toggles",
		["locBonkSFXMenuAdvencedTogglesDesc"] = "Set which melee weapons produce sounds when you hit somebody",
		["locBonkSFXMenuAdvencedSubTogglesDesc"] = "Toggle sound for this weapon"
	})
end)
