Hooks:PostHook(GameSetup, "init_finalize", "UTAnnouncer:init", function(self)
	UTAnnouncer:_init()
end)

Hooks:Add("GameSetupUpdate", "UTAnnouncer:update", function(t, dt)
	UTAnnouncer:_update(t, dt)
end)