_G.UTAnnouncer = _G.UTAnnouncer or {}
UTAnnouncer.savePath = SavePath .. "UTAnnouncer.txt"
UTAnnouncer.audioPath = ModPath .. "audio/"
UTAnnouncer.localizationPath = ModPath .. "loc/"

function UTAnnouncer:defaultSettings()
	self.settings = {
		soundEnabled = true,
		textsEnabled = true,
		textTopYPos = 0.15,
		textTopXPos = 0.5,
		textBottomYPos = 0.85,
		textBottomXPos = 0.5,
		textScale = 1.15,
		volume = 1,
		voice = 3
	}
end
UTAnnouncer:defaultSettings()

function UTAnnouncer:load()
	local file = io.open(self.savePath, "r")
	if file then
		for k, v in pairs(json.decode(file:read("*all"))) do
			self.settings[k] = v
		end
		file:close()
	else
		self:save()
	end
end

function UTAnnouncer:save()
	local file = io.open(self.savePath, "w+")
	if file then
		file:write(json.encode(self.settings))
		file:close()
	end
end

-- Menus

Hooks:Add("LocalizationManagerPostInit", "UTAnnouncer:localizationInit", function(loc)
	loc:load_localization_file(UTAnnouncer.localizationPath .. "english.txt")
end)

Hooks:Add("MenuManagerInitialize", "UTAnnouncer:menuManagerInit", function()
	UTAnnouncer:defaultSettings()
	UTAnnouncer:load()
end)

Hooks:Add("MenuManagerSetupCustomMenus", "UTAnnouncer:setupCustomMenus", function()
	MenuHelper:NewMenu("UTAnnouncerMenu")
end)

Hooks:Add("MenuManagerPopulateCustomMenus", "UTAnnouncer:populateCustomMenus", function()
	local items = {
		"UTAnnouncerVoice1",
		"UTAnnouncerVoice2",
		"UTAnnouncerVoice3",
		"UTAnnouncerVoice4",
		"UTAnnouncerVoice5",
		"UTAnnouncerVoice6",
	}
	
	MenuHelper:AddMultipleChoice({
		id = "voice",
		title = "UTAnnouncerVoiceTitle",
		desc = "UTAnnouncerVoiceDesc",
		callback = "UTAnnouncerMenuVoiceChanged",
		items = items,
		value = UTAnnouncer.settings.voice,
		menu_id = "UTAnnouncerMenu",
		priority = 10,
	})
	
	MenuHelper:AddToggle({
		id = "soundEnabled",
		title = "UTAnnouncerSoundEnabledTitle",
		desc = "UTAnnouncerSoundEnabledDesc",
		callback = "UTAnnouncerMenuItemToggle",
		value = UTAnnouncer.settings.soundEnabled,
		menu_id = "UTAnnouncerMenu",
		priority = 9
	})
	
	MenuHelper:AddToggle({
		id = "textsEnabled",
		title = "UTAnnouncerTextsEnabledTitle",
		desc = "UTAnnouncerTextsEnabledDesc",
		callback = "UTAnnouncerMenuItemToggle",
		value = UTAnnouncer.settings.textsEnabled,
		menu_id = "UTAnnouncerMenu",
		priority = 8
	})
	
	MenuHelper:AddSlider({
		id = "textTopXPos",
		title = "UTAnnouncerUpperXTitle",
		desc = "UTAnnouncerUpperXDesc",
		callback = "UTAnnouncerMenuSliderChange",
		value = UTAnnouncer.settings.textTopXPos,
		min = 0,
		max = 1,
		step = 0.05,
		show_value = true,
		menu_id = "UTAnnouncerMenu",
		display_precision = 0,
		is_percentage = true,
		display_scale = 100,
		priority = 7
	})
	
	MenuHelper:AddSlider({
		id = "textTopYPos",
		title = "UTAnnouncerUpperYTitle",
		desc = "UTAnnouncerUpperYDesc",
		callback = "UTAnnouncerMenuSliderChange",
		value = UTAnnouncer.settings.textTopYPos,
		min = 0,
		max = 1,
		step = 0.05,
		show_value = true,
		menu_id = "UTAnnouncerMenu",
		display_precision = 0,
		is_percentage = true,
		display_scale = 100,
		priority = 6
	})
	
	MenuHelper:AddSlider({
		id = "textBottomXPos",
		title = "UTAnnouncerLowerXTitle",
		desc = "UTAnnouncerLowerXDesc",
		callback = "UTAnnouncerMenuSliderChange",
		value = UTAnnouncer.settings.textBottomXPos,
		min = 0,
		max = 1,
		step = 0.05,
		show_value = true,
		menu_id = "UTAnnouncerMenu",
		display_precision = 0,
		is_percentage = true,
		display_scale = 100,
		priority = 5
	})
	
	MenuHelper:AddSlider({
		id = "textBottomYPos",
		title = "UTAnnouncerLowerYTitle",
		desc = "UTAnnouncerLowerYDesc",
		callback = "UTAnnouncerMenuSliderChange",
		value = UTAnnouncer.settings.textBottomYPos,
		min = 0,
		max = 1,
		step = 0.05,
		show_value = true,
		menu_id = "UTAnnouncerMenu",
		display_precision = 0,
		is_percentage = true,
		display_scale = 100,
		priority = 4
	})
	
	MenuHelper:AddSlider({
		id = "textScale",
		title = "UTAnnouncerTextScaleTitle",
		desc = "UTAnnouncerTextScaleDesc",
		callback = "UTAnnouncerMenuSliderChange",
		value = UTAnnouncer.settings.textScale,
		min = 0.25,
		max = 2.5,
		step = 0.05,
		show_value = true,
		menu_id = "UTAnnouncerMenu",
		display_precision = 0,
		is_percentage = true,
		display_scale = 100,
		priority = 3
	})
	
	MenuHelper:AddSlider({
		id = "volume",
		title = "UTAnnouncerVolumeTitle",
		desc = "UTAnnouncerVolumeDesc",
		callback = "UTAnnouncerMenuSliderChange",
		value = UTAnnouncer.settings.volume,
		min = 0,
		max = 1,
		step = 0.05,
		show_value = true,
		menu_id = "UTAnnouncerMenu",
		display_precision = 0,
		is_percentage = true,
		display_scale = 100,
		priority = 2
	})
	
	MenuHelper:AddButton({
		id = "defaults",
		title = "UTAnnouncerDefaultsTitle",
		desc = "UTAnnouncerDefaultsDesc",
		callback = "UTAnnouncerMenuLoadDefaults",
		menu_id = "UTAnnouncerMenu",
		priority = 1,
	})
end)

Hooks:Add("MenuManagerBuildCustomMenus", "UTAnnouncer:buildCustomMenus", function(menu_manager, nodes)
	nodes["UTAnnouncerMenu"] = MenuHelper:BuildMenu("UTAnnouncerMenu", {back_callback = "UTAnnouncerMenuBack"})
	MenuHelper:AddMenuItem(nodes.blt_options, "UTAnnouncerMenu", "UTAnnouncerMenuTitle", "UTAnnouncerMenuDesc")
end)

-- Menu Callbacks

function MenuCallbackHandler:UTAnnouncerMenuLoadDefaults(item)
	UTAnnouncer:defaultSettings()
	local menu = MenuHelper:GetMenu("UTAnnouncerMenu")
	for _, itm in ipairs(menu:items()) do
		local name = itm:parameters().name
		if UTAnnouncer.settings[name] ~= nil then
			if itm:parameters().type == "CoreMenuItemToggle.ItemToggle" then
				itm:set_value(UTAnnouncer.settings[name] and "on" or "off")
			else
				itm:set_value(UTAnnouncer.settings[name])
			end
		end
	end
	UTAnnouncer:save()
end

function MenuCallbackHandler:UTAnnouncerMenuVoiceChanged(item)
	UTAnnouncer.settings.voice = tonumber(item:value())
end

function MenuCallbackHandler:UTAnnouncerMenuBack(item)
	UTAnnouncer:save()
	
	if Utils:IsInGameState() then
		UTAnnouncer:loadAudioBuffers()
	end
end

function MenuCallbackHandler:UTAnnouncerMenuItemToggle(item)
	UTAnnouncer.settings[item:parameters().name] = item:value() == "on"
end

function MenuCallbackHandler:UTAnnouncerMenuSliderChange(item)
	UTAnnouncer.settings[item:parameters().name] = tonumber(item:value())
end

-- Main Logic
function UTAnnouncer:_update(t, dt)
	self.timeData.t = t
	
	local timeDiff = t - self.timeData.killT
	if self.killData.showTextQueueAudio and timeDiff > 0.001 then
		-- Timed Combos
		if self.killData.kills == 2 then
			self:displayText("doubleKill")
			self:queueAudio("doubleKill")
		elseif self.killData.kills == 3 then
			self:displayText("multiKill")
			self:queueAudio("multiKill")
		elseif self.killData.kills == 4 then
			self:displayText("megaKill")
			self:queueAudio("megaKill")
		elseif self.killData.kills == 5 then
			self:displayText("ultraKill")
			self:queueAudio("ultraKill")
		elseif self.killData.kills == 6 then
			self:displayText("monsterKill")
			self:queueAudio("monsterKill")
		elseif self.killData.kills == 7 then
			self:displayText("ludicrousKill")
			self:queueAudio("ludicrousKill")
		elseif self.killData.kills >= 8 and self.killData.kills <= 13  then
			self:displayText("holyShit")
			self:queueAudio("holyShit")
		end
		
		-- Streak combos
		if self.killData.streakLvl <= 5 and self.killData.killsTotal >= 30 then
			self:displayText("wickedSick")
			self:queueAudio("wickedSick")
			self.killData.streakLvl = 6
		elseif self.killData.streakLvl <= 4 and self.killData.killsTotal >= 25 then
			self:displayText("godLike")
			self:queueAudio("godLike")
			self.killData.streakLvl = 5
		elseif self.killData.streakLvl <= 3 and self.killData.killsTotal >= 20 then
			self:displayText("unstoppable")
			self:queueAudio("unstoppable")
			self.killData.streakLvl = 4
		elseif self.killData.streakLvl <= 2 and self.killData.killsTotal >= 15 then
			self:displayText("dominating")
			self:queueAudio("dominating")
			self.killData.streakLvl = 3
		elseif self.killData.streakLvl <= 1 and self.killData.killsTotal >= 10 then
			self:displayText("rampage")
			self:queueAudio("rampage")
			self.killData.streakLvl = 2
		elseif self.killData.streakLvl == 0 and self.killData.killsTotal >= 5 then
			self:displayText("killingSpree")
			self:queueAudio("killingSpree")
			self.killData.streakLvl = 1
		end
		self.killData.showTextQueueAudio = false
	end
	
	if timeDiff > 3 then
		self.killData.kills = 0
	end
	
	self:playNextInQueue()
end

function UTAnnouncer:_init()
	self.killData = {
		killsTotal = 0,
		headshotStreak = 0,
		streakLvl = 0,
		kills = 0,
		firstBlood = false,
		showTextQueueAudio = false
	}
	
	self.timeData = {
		t = 0,
		killT = 0
	}
	
	self.textData = {
		topId = nil,
		bottomId = nil
	}
	
	blt.xaudio.setup()
	self.audioData = {
		buffers = {},
		queue = {},
		activeAudio = {}
	}
	self:loadAudioBuffers()
end

function UTAnnouncer:loadAudioBuffers()
	if self.audioData.activeAudio.buffer then
		self.audioData.activeAudio.buffer:close()
		self.audioData.activeAudio.buffer = nil
		self.audioData.activeAudio.name = nil
	end
	
	for i = #self.audioData.queue, 1, -1 do
		table.remove(self.audioData.queue, i)
	end
	
	for k1, bufferTable in pairs(self.audioData.buffers) do
		for k2, buffer in pairs(bufferTable) do
			if buffer then
				buffer:close(true)
				self.audioData.buffers[k1][k2] = nil
			end
		end
	end
	
	local voices = {}
	voices[1] = {
		dirName = "classic/",
		audioFiles = {
			dominating = {"Dominating"},
			doubleKill = {"DoubleKill"},
			firstBlood = {"FirstBlood"},
			godLike = {"GodLike"},
			headShot = {"HeadShot"},
			killingSpree = {"KillingSpree"},
			megaKill = {"MegaKill"},
			monsterKill = {"MonsterKill"},
			multiKill = {"MultiKill"},
			rampage = {"Rampage"},
			ultraKill = {"UltraKill"},
			unstoppable = {"Unstoppable"}
		}
	}
	
	voices[2] = {
		dirName = "female/",
		audioFiles = {
			dominating = {"Dominating"},
			doubleKill = {"DoubleKill"},
			firstBlood = {"FirstBlood"},
			godLike = {"GodLike"},
			headHunter = {"HeadHunter"},
			headShot = {"HeadShot"},
			holyShit = {"HolyShit"},
			killingSpree = {"KillingSpree"},
			ludicrousKill = {"LudicrousKill"},
			megaKill = {"MegaKill"},
			monsterKill = {"MonsterKill"},
			multiKill = {"MultiKill"},
			rampage = {"Rampage"},
			ultraKill = {"UltraKill"},
			unstoppable = {"Unstoppable"},
			wickedSick = {"WickedSick"}
		}
	}
	
	voices[3] = {
		dirName = "male/",
		audioFiles = {
			dominating = {"Dominating"},
			doubleKill = {"DoubleKill"},
			firstBlood = {"FirstBlood"},
			godLike = {"GodLike"},
			headHunter = {"HeadHunter"},
			headShot = {"HeadShot"},
			holyShit = {"HolyShit"},
			killingSpree = {"KillingSpree"},
			ludicrousKill = {"LudicrousKill"},
			megaKill = {"MegaKill"},
			monsterKill = {"MonsterKill", "MonsterKill2"},
			multiKill = {"MultiKill"},
			rampage = {"Rampage"},
			ultraKill = {"UltraKill"},
			unstoppable = {"Unstoppable"},
			wickedSick = {"WickedSick"}
		}
	}
	
	voices[4] = {
		dirName = "sexy/",
		audioFiles = {
			dominating = {"Dominating"},
			doubleKill = {"DoubleKill"},
			firstBlood = {"FirstBlood"},
			godLike = {"GodLike"},
			headHunter = {"HeadHunter"},
			headShot = {"HeadShot"},
			holyShit = {"HolyShit"},
			killingSpree = {"KillingSpree"},
			ludicrousKill = {"LudicrousKill"},
			megaKill = {"MegaKill"},
			monsterKill = {"MonsterKill"},
			multiKill = {"MultiKill"},
			rampage = {"Rampage"},
			ultraKill = {"UltraKill"},
			unstoppable = {"Unstoppable"},
			wickedSick = {"WickedSick"}
		}
	}
	
	voices[5] = {
		dirName = "ut3/",
		audioFiles = {
			dominating = {"Dominating"},
			doubleKill = {"DoubleKill"},
			firstBlood = {"FirstBlood"},
			godLike = {"GodLike"},
			headHunter = {"HeadHunter"},
			headShot = {"HeadShot"},
			killingSpree = {"KillingSpree"},
			megaKill = {"MegaKill"},
			monsterKill = {"MonsterKill"},
			multiKill = {"MultiKill"},
			rampage = {"Rampage"},
			ultraKill = {"UltraKill"},
			unstoppable = {"Unstoppable"}
		}
	}
	
	voices[6] = {
		dirName = "ut2003/",
		audioFiles = {
			dominating = {"Dominating"},
			doubleKill = {"DoubleKill"},
			firstBlood = {"FirstBlood"},
			godLike = {"GodLike"},
			headHunter = {"HeadHunter"},
			headShot = {"HeadShot"},
			holyShit = {"HolyShit"},
			killingSpree = {"KillingSpree"},
			ludicrousKill = {"LudicrousKill"},
			megaKill = {"MegaKill"},
			monsterKill = {"MonsterKill", "MonsterKill2", "MonsterKill3"},
			multiKill = {"MultiKill"},
			rampage = {"Rampage"},
			ultraKill = {"UltraKill"},
			unstoppable = {"Unstoppable"},
			wickedSick = {"WickedSick"}
		}
	}
	
	local currentVoice = voices[self.settings.voice]
	local dir = currentVoice and self.audioPath .. currentVoice.dirName
	if not dir or not file.DirectoryExists(dir) then
		return
	end
	
	for id, audioFileNames in pairs(currentVoice.audioFiles) do
		for _, name in pairs(audioFileNames) do
			local fullPath = dir .. name .. '.ogg'
			if io.file_is_readable(fullPath) then
				local buffer = XAudio.Buffer:new(fullPath)
				if not self.audioData.buffers[id] then
					self.audioData.buffers[id] = {}
				end
				table.insert(self.audioData.buffers[id], buffer)
			end
		end
	end
end

function UTAnnouncer:_onKillShot(attacker, headshot)
	if attacker ~= managers.player:player_unit() then
		self.killData.firstBlood = true
		return
	end
	self:checkFirstBlood()
	
	self.killData.kills = self.killData.kills + 1
	self.killData.killsTotal = self.killData.killsTotal + 1
	self.timeData.killT = self.timeData.t
	if headshot then
		self.killData.headshotStreak = self.killData.headshotStreak + 1
		if self.killData.headshotStreak == 15 then
			self:displayText("headHunter")
			self:queueAudio("headHunter")
		else
			self:displayText("headShot")
			self:queueAudio("headShot")
		end
	end
	self.killData.showTextQueueAudio = true
end

function UTAnnouncer:checkFirstBlood()
	if self.killData.firstBlood or not (managers.statistics and managers.statistics:started_session_from_beginning()) then
		return
	end

	-- FIRST BLOOD
	self:displayText("firstBlood")
	self:queueAudio("firstBlood")
	self.killData.firstBlood = true
end

function UTAnnouncer:resetStreak()
	self.killData.killsTotal = 0
	self.killData.headshotStreak = 0
	self.killData.streakLvl = 0
end


function UTAnnouncer:queueAudio(id)
	local priorityList = {
		firstBlood = {1, 1},
		headHunter = {1, 2},
		holyShit = {2, 1},
		ludicrousKill = {2, 2},
		monsterKill = {2, 3},
		ultraKill = {2, 4},
		megaKill = {2, 5},
		multiKill = {2, 6},
		doubleKill = {2, 7},
		headShot = {2, 8},
		wickedSick = {3, 1},
		godLike = {3, 2},
		unstoppable = {3, 3},
		dominating = {3, 4},
		rampage = {3, 5},
		killingSpree = {3, 6}
	}
	
	local toAdd = priorityList[id]
	if self.audioData.activeAudio.name then
		local active = priorityList[self.audioData.activeAudio.name]
		if toAdd[1] == active[1] and (active[2] > toAdd[2] or active[2] == toAdd[2]) then
			self.audioData.activeAudio.buffer:close()
			self.audioData.activeAudio.buffer = nil
			self.audioData.activeAudio.name = nil
		end
	end
	
	for i = #self.audioData.queue, 1, -1 do
		local q = priorityList[self.audioData.queue[i]]
		if toAdd[1] == q[1] and (q[2] > toAdd[2] or q[2] == toAdd[2]) then
			table.remove(self.audioData.queue, i)
		end
	end
	table.insert(self.audioData.queue, id)
	
	table.sort(self.audioData.queue, function(a, b)
		local aP = priorityList[a]
		local bP = priorityList[b]
		return aP[1] > bP[1]
	end)
end

function UTAnnouncer:playNextInQueue()
	if table.empty(self.audioData.activeAudio) or self.audioData.activeAudio.buffer:is_closed() and not table.empty(self.audioData.queue) then
		local id = table.remove(self.audioData.queue)
		local bufferTable = self.audioData.buffers[id]
		if not bufferTable or table.empty(bufferTable) or not self.settings.soundEnabled then
			return
		end
		local buffer = bufferTable[math.random(1, #bufferTable)]
		self.audioData.activeAudio.buffer = XAudio.UnitSource:new(XAudio.PLAYER, buffer)
		self.audioData.activeAudio.buffer:set_volume(self.settings.volume or 1)
		self.audioData.activeAudio.name = id
	end
end

-- HUD
function UTAnnouncer:initHud(hud)
	self.hudPanel = hud.panel
	
	if self.hudPanel:child("topTextPanel") then
		self.hudPanel:remove(self.hudPanel:child("topTextPanel"))
	end
	
	if self.hudPanel:child("bottomTextPanel") then
		self.hudPanel:remove(self.hudPanel:child("bottomTextPanel"))
	end
		
	local topPanel = self.hudPanel:panel({
		name = "topTextPanel",
		visible = false,
		layer = 0
	})
	
	topPanel:text({
		name = "text",
		vertical = "center",
		word_wrap = false,
		wrap = false,
		font_size = 28,
		align = "center",
		text = "",
		layer = 1,
		font = "fonts/font_large_mf",
		color = Color("E30F21")
	})
	
	local bottomPanel = self.hudPanel:panel({
		name = "bottomTextPanel",
		visible = false,
		layer = 0
	})
	
	bottomPanel:text({
		name = "text",
		vertical = "center",
		word_wrap = false,
		wrap = false,
		font_size = 28,
		align = "center",
		text = "",
		layer = 1,
		font = "fonts/font_large_mf",
		color = Color("1BB3E6")
	})
end

function UTAnnouncer:displayText(id)	
	if not self.settings.textsEnabled then
		return
	end
	
	local col1 = Color("E30F21")
	local col2 = Color("1BB3E6")
	local lookupTable = {
		doubleKill = {"topTextPanel", managers.localization:text("UTAnnouncerRewardDoubleKill"), 24, col1, 7},
		multiKill = {"topTextPanel", managers.localization:text("UTAnnouncerRewardMultiKill"), 24, col1, 6},
		megaKill = {"topTextPanel", managers.localization:text("UTAnnouncerRewardMegaKill"), 24, col1, 5},
		ultraKill = {"topTextPanel", managers.localization:text("UTAnnouncerRewardUltraKill"), 26, col1, 4},
		monsterKill = {"topTextPanel", managers.localization:text("UTAnnouncerRewardMonsterKill"), 28, col1, 3},
		ludicrousKill = {"topTextPanel", managers.localization:text("UTAnnouncerRewardLudicrousKill"), 28, col1, 2},
		holyShit = {"topTextPanel", managers.localization:text("UTAnnouncerRewardHolyShit"), 28, col1, 1},
		wickedSick = {"bottomTextPanel", managers.localization:text("UTAnnouncerRewardWickedSick"), 24, col2, 3},
		godLike = {"bottomTextPanel", managers.localization:text("UTAnnouncerRewardGodlike"), 24, col2, 4},
		unstoppable = {"bottomTextPanel", managers.localization:text("UTAnnouncerRewardUnstoppable"), 24, col2, 5},
		dominating = {"bottomTextPanel", managers.localization:text("UTAnnouncerRewardDominating"), 24, col2, 6},
		rampage = {"bottomTextPanel", managers.localization:text("UTAnnouncerRewardRampage"), 24, col2, 7},
		killingSpree = {"bottomTextPanel", managers.localization:text("UTAnnouncerRewardKillingSpree"), 24, col2, 8},
		headHunter = {"bottomTextPanel", managers.localization:text("UTAnnouncerRewardHeadHunter"), 24, col2, 2},
		headShot = {"bottomTextPanel", managers.localization:text("UTAnnouncerRewardHeadshot"), 24, col2, 9},
		firstBlood = {"bottomTextPanel", managers.localization:text("UTAnnouncerRewardFirstBlood", {PLAYER = managers.network.account:username() or managers.localization:text("UTAnnouncerRewardFirstBloodMissing")}), 26, col1, 1}
	}
	
	local data = lookupTable[id]
	if not data then
		return
	end
	
	local settings = self.settings
	local x, y = nil
	if data[1] == "topTextPanel" then
		if self.textData.topId and data[5] > lookupTable[self.textData.topId][5] then
			return
		end
		x = settings.textTopXPos or 0.5
		y = settings.textTopYPos or 0.15
		self.textData.topId = id
	elseif data[1] == "bottomTextPanel" then
		if self.textData.bottomId and data[5] > lookupTable[self.textData.bottomId][5] then
			return
		end
		x = settings.textBottomXPos or 0.5
		y = settings.textBottomYPos or 0.85
		self.textData.bottomId = id
	end
	
	local hudPanel = self.hudPanel
	local panel = hudPanel and hudPanel:child(data[1])
	local textField = panel and panel:child("text")
	if not textField then
		return
	end
	
	textField:set_font_size(data[3] * (settings.textScale or 1.15))
	textField:set_text(data[2])
	textField:set_color(data[4])
	panel:set_center_x(hudPanel:w() * x)
	panel:set_center_y(hudPanel:h() * y)
	
	local function fadeOut(panel)
		panel:show()
		panel:set_alpha(1)
		local waitT = 3
		local fadeT = 2
		local t = 0

		while waitT > t do
			local dt = coroutine.yield()
			t = t + dt
		end
			
		if panel:name() == "topTextPanel" then
			self.textData.topId = nil
		end
		
		if panel:name() == "bottomTextPanel" then
			self.textData.bottomId = nil
		end
		
		local t = 0
		while fadeT > t do
			local dt = coroutine.yield()
			t = t + dt
			panel:set_alpha(1 - t / fadeT)
		end

		panel:set_alpha(0)
		panel:hide()
	end
	
	panel:stop()
	panel:animate(fadeOut)
end