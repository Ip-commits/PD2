Hooks:PostHook(CopDamage, "chk_killshot", "UTAnnouncer:onKillShot", function(self, attacker, variant, headshot, weaponId)
	local victimIsCiv = CopDamage.is_civilian(self._unit:base()._tweak_table)
	if not attacker or victimIsCiv then
		return
	end	
	UTAnnouncer:_onKillShot(attacker, headshot)
end)