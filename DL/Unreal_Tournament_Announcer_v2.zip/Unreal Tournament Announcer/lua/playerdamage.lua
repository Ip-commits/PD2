Hooks:PostHook(PlayerDamage, "revive", "UTAnnouncer:playerRevive", function(...)
	UTAnnouncer:resetStreak()
end)

Hooks:PostHook(PlayerDamage, "on_arrested", "UTAnnouncer:playerArrest", function(...)
	UTAnnouncer:resetStreak()
end)