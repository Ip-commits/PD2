Hooks:PostHook(HUDManager, "_setup_player_info_hud_pd2", "UTAnnouncer:initHud", function(self)
	if not self:alive(PlayerBase.PLAYER_INFO_HUD_PD2) then
		return
	end

	UTAnnouncer:initHud(managers.hud:script(PlayerBase.PLAYER_INFO_HUD_PD2))
end)