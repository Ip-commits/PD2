const serverUrl = 'http://localhost:3085';

document.addEventListener('DOMContentLoaded', () => {
	const urlParams = new URLSearchParams(window.location.search);
	const tab = urlParams.get('tab');
	
	switch(tab) {
		case 'playerInfo':
			showPlayerInfo(urlParams.get('id'));
			break;
		default:
			showPlayHistory(1);
	}
	
	// add enter key listener to search input
	document.querySelector('#searchInput').addEventListener('keypress', e => {
		if(e.key == 'Enter') {
			e.preventDefault();
			document.querySelector('#searchBtn').click();
		}
	});
});

function searchBtnEvent() {
	const searchInput = document.querySelector('#searchInput');
	const searchStr = searchInput.value.trim();
	
	if(searchStr == '') return;	
	fetch(serverUrl + '/history/genSearchTable', {
		headers: {
			'Content-type' : 'application/json'
		},
		method: 'POST',
		body: JSON.stringify({searchStr: searchStr})
	})
	.then(response => {
		if(!response.ok) {
			return response.json().then(data => {throw new Error(data.message)});
		}
		return response.json();
	})
	.then(data => {showSearchResults(1);})
	.catch(err => displayErrorMsg('ERROR', err.message));
}

function showSearchResults(page) {
	fetch(serverUrl + '/history/getSearchRes', {
		headers: {
			'Content-type' : 'application/json'
		},
		method: 'POST',
		body: JSON.stringify({page: page})
	})
	.then(response => {
		if(!response.ok) {
			return response.json().then(data => {throw new Error(data.message)});
		}
		return response.json();
	})
	.then(data => createMainTables(data, 'search'))
	.catch(err => displayErrorMsg('ERROR', err.message));
}

function showPlayHistory(page) {
	fetch(serverUrl + '/history/lastPlayed', {
		headers: {
			'Content-type' : 'application/json'
		},
		method: 'POST',
		body: JSON.stringify({page: page})
	})
	.then(response => {
		if(!response.ok) {
			return response.json().then(data => {throw new Error(data.message)});
		}
		return response.json();
	})
	.then(data => createMainTables(data, 'playHistory'))
	.catch(err => displayErrorMsg('ERROR', err.message));
}

function showPlayerInfo(id) {
	fetch(serverUrl + '/history/playerData/' + id)
	.then(response => {
		if(!response.ok) {
			return response.json().then(data => {throw new Error(data.message)});
		}
		return response.json();
	})
	.then(data => createPlayerInfoTables(data))
	.catch(err => displayErrorMsg('Error', err.message));
}

function createPlayerInfoTables(data) {	
	const contentDiv = document.querySelector('#content');
	let nameDate = data.names.shift();
	let html = `<input type="hidden" id="playerId" value="${data.playerInfo.player_id}">`;
	html += '<h1>Player info</h1>';
	html += '<table class="dataTable dataTableTh1">';
	html += '<tr>';
	html += '<th>Player ID</th>';
	html += '<th>Name</th>';
	html += '<th>Account type</th>';
	html += '</tr>';
	html += '<tr>';
	html += `<td>${data.playerInfo.player_id}</td>`;
	html += `<td>${nameDate.name}</td>`;
	html += `<td>${data.playerInfo.platform}</td>`;
	html += '</tr>';
	html += '<tr>';
	html += '<th>Last status</th>';
	html += '<th>First seen</th>';
	html += '<th>Last seen</th>';
	html += '</tr>';
	html += '<tr>';
	html += `<td>${data.playerInfo.last_status}</td>`;
	html += `<td>${data.playerInfo.first_encounter}</td>`;
	html += `<td>${data.playerInfo.last_encounter}</td>`;
	html += '</tr>';
	if(data.names.length > 0) {
		html += '<tr>';
		html += '<th colspan="2">Other names</th>';
		html += '<th>Other name seen</th>';
		html += '</tr>';
		data.names.forEach(nameDate => {
			html += `<tr><td colspan="2">${nameDate.name}</td><td>${nameDate.date}</td></tr>`;
		});
	}
	html += '<tr>';
	html += '<th colspan="3">Notes</th>';
	html += '</tr>';
	html += '<tr>';
	html += '<td colspan="3"><div id="notes"></div></td>';
	html += '</tr>';
	html += '</table>';	
	
	html += '<h1>Mods</h1>';
	html += '<table class="dataTable dataTableTh1">';
	if(data.mods.length == 0) {
		html += '<tr><td>No mods on record.</td></tr>';
	} else {
		html += '<tr>';
		html += '<th>Initial</th>';
		html += '<th>Mod name / directory</th>';
		html += '<th>Status</th>';
		html += '<th>Change date</th>';
		html += '</tr>';
		data.mods.forEach(mod => {
			html += '<tr>';
			html += `<td>${mod.is_initial == 1 ? '&#9745;' : '&#9744;'}</td>`;
			html += '<td>';
			html += '<ul>';
			html += `<li>${mod.mod_name}</li>`;
			if(mod.dir_name != mod.mod_name)
				html += `<li class="secCol">${mod.dir_name}</li>`;
			html += '</ul>';
			html += '</td>';
			html += `<td>${mod.mod_state}</td>`;
			html += `<td>${mod.change_date}</td>`;
			html += '</tr>';
		});
	}
	html += '</table>';
	contentDiv.innerHTML = html;
	
	displayNotes(data.playerInfo.notes, false);
}

function displayNotes(str, edit) {
	const notes = document.querySelector('#notes');
	if(str === undefined || str === null) str = '';
	let html = '';
	if(edit) {
		if(str == 'NONE') str = '';
		html += `<textarea oninput="resizeTextArea(this)" cols="80">${str}</textarea>`;
		html += `<input id="oldNote" type="hidden" value="${str}">`;
		html += '<button onclick="saveNoteChange()">Save</button>';
		html += '<button onclick="cancelNoteChange()">Cancel</button>';
		notes.innerHTML = html;
		
		const textarea = document.querySelector('#notes textarea');
		textarea.style.height = textarea.scrollHeight + 'px';
		textarea.style.width = notes.getBoundingClientRect().width + 'px';
		textarea.style.overflowY = 'hidden';
	} else {
		if(str == '') str = 'NONE';
		html += `<pre>${str}</pre>`;
		html += '<button onclick="editNotes()">Edit</button>';
		notes.innerHTML = html;
	}
}

function resizeTextArea(elem) {
	elem.style.height = 'auto';
	elem.style.height = elem.scrollHeight + 'px';
}

function editNotes() {
	const notes = document.querySelector('#notes');
	const elem = notes.querySelector('pre');
	displayNotes(elem.innerText.trim(), true);
}

function cancelNoteChange() {
	displayNotes(document.querySelector('#oldNote').value, false);
}

function saveNoteChange() {
	const notes = document.querySelector('#notes');
	const elem = notes.querySelector('textarea');
	const str = elem.value.trim();
	const playerId = document.querySelector('#playerId').value;
	dbUpdateNotes(playerId, str);
	displayNotes(str, false);
}

function dbUpdateNotes(id, str) {
	fetch(serverUrl + '/history/updateNotes', {
		headers: {
			'Content-type' : 'application/json'
		},
		method: 'PATCH',
		body: JSON.stringify({player_id: id, notes: str})
	})
	.then(response => {
		if(!response.ok) {
			return response.json().then(data => {throw new Error(data.message)});
		}
		return response.json();
	})
	.then(data => {
		const notes = document.querySelector('#notes');
		let span = notes.querySelector('#noteSaveResult');
		if(!span) {
			span = document.createElement('span');
			span.id = 'noteSaveResult';
			notes.appendChild(span);
		}
		
		span.innerText = data.message;
	})
	.catch(err => displayErrorMsg('ERROR', err.message));
}

function createMainTables(data, tab) {
	const contentDiv = document.querySelector('#content');
	let html = `<h1>${tab == 'search' ? 'Search Results' : 'Play History'}</h1>`;
	html += '<table class="dataTable dataTableTh1">';
	if(data.rows.length == 0) {
		html += '<tr><td>No records found.</td></tr>';
	} else {
		html += '<tr>';
		html += '<th>Name</th>';
		html += '<th>Player ID</th>';
		html += '<th>Account type</th>';
		html += '<th>Status</th>';
		html += '<th>Last seen</th>';
		html += '<th>Mods / Info</th>';
		html += '</tr>';
		data.rows.forEach(item => {
			html += '<tr>';
			html += `<td class="noTextTransform">${item.name}</td>`;
			html += `<td>${item.player_id}</td>`;
			html += `<td>${item.platform}</td>`;
			html += `<td>${item.last_status}</td>`;
			html += `<td>${item.last_encounter}</td>`;
			html += `<td><a href="index.html?tab=playerInfo&id=${item.player_id}">Player Info</a></td>`;
			html += '</tr>';
		});
	}
	html += '</table>';
	if(data.maxPages > 1) {
		html += addPageSelect(data.page, data.maxPages, tab);
	}
	contentDiv.innerHTML = html;
}

function addPageSelect(currentPage, maxPages, tab) {
	let html = '<div class="pageSelect">';
	if(currentPage > 1) {
		html += `<a href="javascript:jumpToPage(1, '${tab}');"><< First</a>`;
		html += `<a href="javascript:jumpToPage(${currentPage - 1}, '${tab}');">< Prev</a>`;
	} else {
		html += '<span></span>';
		html += '<span></span>';
	}
	
	if(maxPages > 1) {
		html += `<input type="number" min="1" max="${maxPages}" step="1" value="${currentPage}" onchange="pageSelectInputChange(this, '${tab}')">`;
	}
	
	if(currentPage < maxPages) {
		html += `<a href="javascript:jumpToPage(${currentPage + 1}, '${tab}');">Next ></a>`;
		html += `<a href="javascript:jumpToPage(${maxPages}, '${tab}');">Last >></a>`;
	} else {
		html += '<span></span>';
		html += '<span></span>';
	}
	html += '</div>';
	return html;
}

function displayErrorMsg(title, text) {
	const contentDiv = document.querySelector('#content');
	let html = `<h1>${title}</h1>`;
	html += `<p>${text}</p>`;
	contentDiv.innerHTML = html;
}

function pageSelectInputChange(input, tab) {
	if(input.value > input.max) input.value = input.max;
	if(input.value < input.min) input.value = input.min;
	jumpToPage(input.value, tab);
}

function jumpToPage(page, tab) {
	switch(tab) {
		case 'playHistory':
			showPlayHistory(page);
			break;
		case 'search':
			showSearchResults(page);
	}
}