-- Wait for players to sync, then after 2 seconds check if their mods need to be added to the data base
Hooks:PostHook(BaseNetworkSession, "on_peer_sync_complete", "PlayerHistory:scanPeerMods", function(self, peer, peer_id)
	if not peer then return end
	local accID = peer:account_id()
	local gph = Global.GLPlayerHistory
	local gphPlayer = gph and gph.playerInfo and gph.playerInfo[accID]
	if not gphPlayer then return end
	
	DelayedCalls:Add("PlayerHistoryScanMods_" .. tostring(accID), 2, function()
		for _, peer2 in pairs(managers.network:session():peers()) do
			if peer2:account_id() == accID then
				local mods = peer2:synced_mods() or {}
				if not gphPlayer.numMods or gphPlayer.numMods < #mods then
					PlayerHistory:updateModRegistry(accID, mods)
					gphPlayer.numMods = #mods
				end
				break
			end
		end
	end)
end)