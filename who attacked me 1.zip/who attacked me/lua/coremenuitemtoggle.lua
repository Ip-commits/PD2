core:module("CoreMenuItemToggle")

local ogSize = nil
Hooks:PreHook(ItemToggle, "reload", "WhoAttackedMe:preReloadToggleGui", function(self, row_item, node)
	if self.parameters and self:parameters().isCustomToggle then
		ogSize = node.font_size
		node.font_size = self:parameters().fSize or 18
		row_item.gui_text:set_text(row_item.item:value() == "on" and managers.localization:text("locWhoAttackedMeEnabled") or managers.localization:text("locWhoAttackedMeDisabled"))
	end
end)

Hooks:PostHook(ItemToggle, "reload", "WhoAttackedMe:postReloadToggleGui", function(self, row_item, node)
	if self.parameters and self:parameters().isCustomToggle then
		node.font_size = ogSize or 24
	end
end)

Hooks:PreHook(ItemToggle, "setup_gui", "WhoAttackedMe:preSetupToggleGui", function(self, node, row_item)
	row_item.align = "left"
end)
